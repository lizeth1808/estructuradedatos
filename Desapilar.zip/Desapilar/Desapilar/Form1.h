#pragma once
#include "Pila.h"

namespace Desapilar {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace std;

	Pila P1;
	Pila P2; 
	int pos=0;

	/// <summary>
	/// Summary for Form1
	/// </summary>
	public ref class Form1 : public System::Windows::Forms::Form
	{
	public:
		Form1(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::TextBox^  txtApilar;
	protected: 
	private: System::Windows::Forms::TextBox^  txtDesapilar;
	private: System::Windows::Forms::Button^  btnApilar;
	private: System::Windows::Forms::Button^  btnDesapilar;
	private: System::Windows::Forms::DataGridView^  Grid;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  Column1;
	private: System::Windows::Forms::TextBox^  txtPos;
	private: System::Windows::Forms::TextBox^  txtNum;
	private: System::Windows::Forms::Button^  btnIn;

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->txtApilar = (gcnew System::Windows::Forms::TextBox());
			this->txtDesapilar = (gcnew System::Windows::Forms::TextBox());
			this->btnApilar = (gcnew System::Windows::Forms::Button());
			this->btnDesapilar = (gcnew System::Windows::Forms::Button());
			this->Grid = (gcnew System::Windows::Forms::DataGridView());
			this->Column1 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->txtPos = (gcnew System::Windows::Forms::TextBox());
			this->txtNum = (gcnew System::Windows::Forms::TextBox());
			this->btnIn = (gcnew System::Windows::Forms::Button());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->Grid))->BeginInit();
			this->SuspendLayout();
			// 
			// txtApilar
			// 
			this->txtApilar->Location = System::Drawing::Point(35, 31);
			this->txtApilar->Name = L"txtApilar";
			this->txtApilar->Size = System::Drawing::Size(100, 20);
			this->txtApilar->TabIndex = 0;
			// 
			// txtDesapilar
			// 
			this->txtDesapilar->Location = System::Drawing::Point(35, 83);
			this->txtDesapilar->Name = L"txtDesapilar";
			this->txtDesapilar->Size = System::Drawing::Size(100, 20);
			this->txtDesapilar->TabIndex = 1;
			// 
			// btnApilar
			// 
			this->btnApilar->Location = System::Drawing::Point(190, 31);
			this->btnApilar->Name = L"btnApilar";
			this->btnApilar->Size = System::Drawing::Size(75, 23);
			this->btnApilar->TabIndex = 2;
			this->btnApilar->Text = L"Apilar";
			this->btnApilar->UseVisualStyleBackColor = true;
			this->btnApilar->Click += gcnew System::EventHandler(this, &Form1::btnApilar_Click);
			// 
			// btnDesapilar
			// 
			this->btnDesapilar->Location = System::Drawing::Point(190, 83);
			this->btnDesapilar->Name = L"btnDesapilar";
			this->btnDesapilar->Size = System::Drawing::Size(75, 23);
			this->btnDesapilar->TabIndex = 3;
			this->btnDesapilar->Text = L"Desapilar";
			this->btnDesapilar->UseVisualStyleBackColor = true;
			this->btnDesapilar->Click += gcnew System::EventHandler(this, &Form1::btnDesapilar_Click);
			// 
			// Grid
			// 
			this->Grid->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->Grid->Columns->AddRange(gcnew cli::array< System::Windows::Forms::DataGridViewColumn^  >(1) {this->Column1});
			this->Grid->Location = System::Drawing::Point(35, 130);
			this->Grid->Name = L"Grid";
			this->Grid->Size = System::Drawing::Size(240, 150);
			this->Grid->TabIndex = 4;
			this->Grid->RowCount=25;
			// 
			// Column1
			// 
			this->Column1->HeaderText = L"Column1";
			this->Column1->Name = L"Column1";
			// 
			// txtPos
			// 
			this->txtPos->Location = System::Drawing::Point(333, 195);
			this->txtPos->Name = L"txtPos";
			this->txtPos->Size = System::Drawing::Size(100, 20);
			this->txtPos->TabIndex = 5;
			// 
			// txtNum
			// 
			this->txtNum->Location = System::Drawing::Point(333, 234);
			this->txtNum->Name = L"txtNum";
			this->txtNum->Size = System::Drawing::Size(100, 20);
			this->txtNum->TabIndex = 6;
			// 
			// btnIn
			// 
			this->btnIn->Location = System::Drawing::Point(468, 212);
			this->btnIn->Name = L"btnIn";
			this->btnIn->Size = System::Drawing::Size(75, 23);
			this->btnIn->TabIndex = 7;
			this->btnIn->Text = L"Insertar";
			this->btnIn->UseVisualStyleBackColor = true;
			this->btnIn->Click += gcnew System::EventHandler(this, &Form1::btnIn_Click);
			// 
			// Form1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(686, 307);
			this->Controls->Add(this->btnIn);
			this->Controls->Add(this->txtNum);
			this->Controls->Add(this->txtPos);
			this->Controls->Add(this->Grid);
			this->Controls->Add(this->btnDesapilar);
			this->Controls->Add(this->btnApilar);
			this->Controls->Add(this->txtDesapilar);
			this->Controls->Add(this->txtApilar);
			this->Name = L"Form1";
			this->Text = L"Form1";
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->Grid))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void btnApilar_Click(System::Object^  sender, System::EventArgs^  e) {
				 int elem;
				 elem=Convert::ToInt32(txtApilar->Text);
				 P1.Insertar(elem);
				 Grid->Rows[pos++]->Cells[0]->Value=elem;
			 }
private: System::Void btnDesapilar_Click(System::Object^  sender, System::EventArgs^  e) {
			 int elem;
			 P1.Eliminar(elem);
			 Grid->Rows->RemoveAt(--pos);
		 }
		 
private: System::Void btnIn_Click(System::Object^  sender, System::EventArgs^  e) {
			 int elem;
			 int posi= System::Convert::ToInt32(txtPos->Text);
			 int num= System::Convert::ToInt32(txtNum->Text);
			 while(posi<=pos-1)
			 {
				 P1.Eliminar(elem);
				 P2.Insertar(elem);
				 Grid->Rows->RemoveAt(pos);
				 pos--;
			 }
			 Grid->Rows[pos]->Cells[0]->Value= num;
			 while(P2.Vacia()==false)
			 {
				 P2.Eliminar(elem);
				 P1.Insertar(elem);
				 pos++;
				 Grid->Rows[pos]->Cells[0]->Value= elem;
				 
			 }
		 }
};
}

