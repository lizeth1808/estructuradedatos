#pragma once
#define N 8
class Pila
{private:
	int V[N];
	int tope;
public:
	Pila(void);
	int Get_tope();
	bool Vacia();
	bool Llena();
	bool Insertar(int x);
	bool Eliminar(int &x);

};

