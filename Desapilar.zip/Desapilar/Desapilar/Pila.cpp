#include "StdAfx.h"
#include "Pila.h"


Pila::Pila(void)
{
	tope=-1;
	V[N]=0;
}
bool Pila::Vacia()
{
	if(tope==-1)
		return true;
	else
		return false;
}
bool Pila::Llena()
{
	if(tope==N-1)
		return true;
	else
		return false;

}
	bool Pila::Insertar(int x)
	{
		if(Llena()==true)
			return false;
		else 
		{
			V[++tope]=x;
			return true;
		}
	}
	bool Pila::Eliminar(int &x)
	{
		if(Vacia()==true)
			return false;
		else
			{x= V[tope--];
			return true;
		}
	}
	int Pila::Get_tope()
	{
		return tope;
	}
