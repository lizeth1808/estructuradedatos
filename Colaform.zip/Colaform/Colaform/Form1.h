#pragma once
#include "Cola.h"
#include "NODO.h"

namespace Colaform {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace std;

	Cola aux;
	NODO B;
	Cola A;
	int pos=0;
	/// <summary>
	/// Summary for Form1
	/// </summary>
	public ref class Form1 : public System::Windows::Forms::Form
	{
	public:
		Form1(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::TextBox^  txtTam;
	protected: 
	private: System::Windows::Forms::TextBox^  txtEncolar;
	private: System::Windows::Forms::Button^  btnTam;
	private: System::Windows::Forms::Button^  btnEncolar;
	private: System::Windows::Forms::DataGridView^  Grid1;

	private: System::Windows::Forms::TextBox^  textBox1;
	private: System::Windows::Forms::Button^  btnInvertir;

	private: System::Windows::Forms::DataGridViewTextBoxColumn^  Column1;
	private: System::Windows::Forms::TextBox^  txtNum;
	private: System::Windows::Forms::DataGridView^  Grid2;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  Column2;

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->txtTam = (gcnew System::Windows::Forms::TextBox());
			this->txtEncolar = (gcnew System::Windows::Forms::TextBox());
			this->btnTam = (gcnew System::Windows::Forms::Button());
			this->btnEncolar = (gcnew System::Windows::Forms::Button());
			this->Grid1 = (gcnew System::Windows::Forms::DataGridView());
			this->Column1 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->textBox1 = (gcnew System::Windows::Forms::TextBox());
			this->btnInvertir = (gcnew System::Windows::Forms::Button());
			this->txtNum = (gcnew System::Windows::Forms::TextBox());
			this->Grid2 = (gcnew System::Windows::Forms::DataGridView());
			this->Column2 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->Grid1))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->Grid2))->BeginInit();
			this->SuspendLayout();
			// 
			// txtTam
			// 
			this->txtTam->Location = System::Drawing::Point(60, 31);
			this->txtTam->Name = L"txtTam";
			this->txtTam->Size = System::Drawing::Size(100, 20);
			this->txtTam->TabIndex = 0;
			// 
			// txtEncolar
			// 
			this->txtEncolar->Location = System::Drawing::Point(60, 75);
			this->txtEncolar->Name = L"txtEncolar";
			this->txtEncolar->Size = System::Drawing::Size(100, 20);
			this->txtEncolar->TabIndex = 1;
			// 
			// btnTam
			// 
			this->btnTam->Location = System::Drawing::Point(219, 31);
			this->btnTam->Name = L"btnTam";
			this->btnTam->Size = System::Drawing::Size(75, 23);
			this->btnTam->TabIndex = 2;
			this->btnTam->Text = L"Tamano";
			this->btnTam->UseVisualStyleBackColor = true;
			this->btnTam->Click += gcnew System::EventHandler(this, &Form1::btnTam_Click);
			// 
			// btnEncolar
			// 
			this->btnEncolar->Location = System::Drawing::Point(219, 72);
			this->btnEncolar->Name = L"btnEncolar";
			this->btnEncolar->Size = System::Drawing::Size(75, 23);
			this->btnEncolar->TabIndex = 3;
			this->btnEncolar->Text = L"Encolar";
			this->btnEncolar->UseVisualStyleBackColor = true;
			this->btnEncolar->Click += gcnew System::EventHandler(this, &Form1::btnEncolar_Click);
			// 
			// Grid1
			// 
			this->Grid1->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->Grid1->Columns->AddRange(gcnew cli::array< System::Windows::Forms::DataGridViewColumn^  >(1) {this->Column1});
			this->Grid1->Location = System::Drawing::Point(60, 138);
			this->Grid1->Name = L"Grid1";
			this->Grid1->Size = System::Drawing::Size(234, 143);
			this->Grid1->TabIndex = 4;
			// 
			// Column1
			// 
			this->Column1->HeaderText = L"Column1";
			this->Column1->Name = L"Column1";
			// 
			// textBox1
			// 
			this->textBox1->Location = System::Drawing::Point(346, 75);
			this->textBox1->Name = L"textBox1";
			this->textBox1->Size = System::Drawing::Size(100, 20);
			this->textBox1->TabIndex = 5;
			// 
			// btnInvertir
			// 
			this->btnInvertir->Location = System::Drawing::Point(452, 75);
			this->btnInvertir->Name = L"btnInvertir";
			this->btnInvertir->Size = System::Drawing::Size(75, 23);
			this->btnInvertir->TabIndex = 6;
			this->btnInvertir->Text = L"Invertir";
			this->btnInvertir->UseVisualStyleBackColor = true;
			this->btnInvertir->Click += gcnew System::EventHandler(this, &Form1::btnInvertir_Click);
			// 
			// txtNum
			// 
			this->txtNum->Location = System::Drawing::Point(60, 101);
			this->txtNum->Name = L"txtNum";
			this->txtNum->Size = System::Drawing::Size(100, 20);
			this->txtNum->TabIndex = 7;
			// 
			// Grid2
			// 
			this->Grid2->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->Grid2->Columns->AddRange(gcnew cli::array< System::Windows::Forms::DataGridViewColumn^  >(1) {this->Column2});
			this->Grid2->Location = System::Drawing::Point(346, 138);
			this->Grid2->Name = L"Grid2";
			this->Grid2->Size = System::Drawing::Size(240, 143);
			this->Grid2->TabIndex = 8;
			// 
			// Column2
			// 
			this->Column2->HeaderText = L"Column2";
			this->Column2->Name = L"Column2";
			// 
			// Form1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(670, 293);
			this->Controls->Add(this->Grid2);
			this->Controls->Add(this->txtNum);
			this->Controls->Add(this->btnInvertir);
			this->Controls->Add(this->textBox1);
			this->Controls->Add(this->Grid1);
			this->Controls->Add(this->btnEncolar);
			this->Controls->Add(this->btnTam);
			this->Controls->Add(this->txtEncolar);
			this->Controls->Add(this->txtTam);
			this->Name = L"Form1";
			this->Text = L"Form1";
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->Grid1))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->Grid2))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void btnTam_Click(System::Object^  sender, System::EventArgs^  e) {
				 int tam;
				 tam= System::Convert::ToInt32(txtTam->Text);
				 Grid1->RowCount= tam;
				 Grid1->ColumnCount=2;
			 }
private: System::Void btnEncolar_Click(System::Object^  sender, System::EventArgs^  e) {
			 int num, reg;
			 num= System::Convert::ToInt32(txtEncolar->Text);
			 reg= System::Convert::ToInt32(txtNum->Text);
			 B.Agregar(num,reg);
			 A.Insertar(B);
			 Grid1->Rows[pos]->Cells[0]->Value= num;
			 Grid1->Rows[pos]->Cells[1]->Value= reg;
			 pos++;
		 }
private: System::Void btnInvertir_Click(System::Object^  sender, System::EventArgs^  e) {
			 int i=0;
			 int elem;
			 while(A.Vacia()==false)
			 {

			   A.Eliminar(B);		  
			   Grid2->Rows[i]->Cells[0]->Value= B.Get_Numero();
			   Grid2->Rows[i]->Cells[1]->Value= B.Get_Registro();
			    aux.Insertar(B);
			   i++;
			 }
			 
		 }
};
}

