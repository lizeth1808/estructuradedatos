#pragma once
#include "NODO.h"

#define N 9

class Cola
{
private:
	int frente;
	int final;
	NODO V[N];
public:
	Cola(void);
	bool Vacia();
	bool Llena();
	bool Insertar(NODO x);
	bool Eliminar(NODO &x);

};

