#include "StdAfx.h"
#include "NODO.h"


NODO::NODO(void)
{
}
void NODO::Agregar(int num, int reg)
{
	Numero=num;
	Registro= reg;
}

int NODO::Get_Numero()
{
	return Numero;
}
void NODO::Set_Numero(int num)
	{
		Numero=num;
	}
int NODO::Get_Registro()
	{
		return Registro;
	}
void NODO::Set_Registro(int reg)
	{
		Registro=reg;
	}
