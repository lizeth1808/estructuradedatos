#pragma once
class NODO
{
private:
	int Numero;
	int Registro;
public:
	NODO(void);
	void Agregar(int num, int reg);
	int Get_Numero();
	void Set_Numero(int num);
	int Get_Registro();
	void Set_Registro(int reg);
};

