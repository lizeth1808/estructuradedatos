#pragma once
#define N 20
#define M 40
ref class Interr
{
private:
	double vec[N];
	int tamano;
public:
	Interr(void);
	double Get_vector(int posicion);
	void Set_vector(int posicion, double elemento);
	int Get_tamano();
	void Set_tamano(int tam);
	bool Llenar();
	bool VacioVector();
	bool Lenar(int posicion, double elemento);
	Interr Concatenar(Interr vec1, Interr vec2);
};

