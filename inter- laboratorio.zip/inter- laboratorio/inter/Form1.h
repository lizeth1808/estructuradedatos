#pragma once
#include "Interr.h"

namespace inter {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace std;

	Interr In3;
	Interr In1;
	Interr In2;
	int pos=0;
	/// <summary>
	/// Summary for Form1
	/// </summary>
	public ref class Form1 : public System::Windows::Forms::Form
	{
	public:
		Form1(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Label^  label1;
	private: System::Windows::Forms::TextBox^  txtTamano1;
	protected: 

	protected: 

	protected: 

	private: System::Windows::Forms::Label^  label2;
	private: System::Windows::Forms::TextBox^  txtTamano2;

	private: System::Windows::Forms::Button^  btnIngresar;
	private: System::Windows::Forms::Button^  btnIngresar2;


	private: System::Windows::Forms::Label^  label3;
	private: System::Windows::Forms::Label^  label4;
	private: System::Windows::Forms::TextBox^  txtTamano3;
	private: System::Windows::Forms::TextBox^  txtTamano4;


	private: System::Windows::Forms::Button^  btnIngresar3;

	private: System::Windows::Forms::Button^  btnIngresar4;

	private: System::Windows::Forms::DataGridView^  grilla1;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  Column1;
	private: System::Windows::Forms::DataGridView^  grilla2;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  Column2;
	private: System::Windows::Forms::DataGridView^  grilla3;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  Column3;
	private: System::Windows::Forms::Button^  btnIntercalar;


	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->txtTamano1 = (gcnew System::Windows::Forms::TextBox());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->txtTamano2 = (gcnew System::Windows::Forms::TextBox());
			this->btnIngresar = (gcnew System::Windows::Forms::Button());
			this->btnIngresar2 = (gcnew System::Windows::Forms::Button());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->label4 = (gcnew System::Windows::Forms::Label());
			this->txtTamano3 = (gcnew System::Windows::Forms::TextBox());
			this->txtTamano4 = (gcnew System::Windows::Forms::TextBox());
			this->btnIngresar3 = (gcnew System::Windows::Forms::Button());
			this->btnIngresar4 = (gcnew System::Windows::Forms::Button());
			this->grilla1 = (gcnew System::Windows::Forms::DataGridView());
			this->Column1 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->grilla2 = (gcnew System::Windows::Forms::DataGridView());
			this->Column2 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->grilla3 = (gcnew System::Windows::Forms::DataGridView());
			this->Column3 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->btnIntercalar = (gcnew System::Windows::Forms::Button());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->grilla1))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->grilla2))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->grilla3))->BeginInit();
			this->SuspendLayout();
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Location = System::Drawing::Point(26, 43);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(46, 13);
			this->label1->TabIndex = 0;
			this->label1->Text = L"Tamano";
			// 
			// txtTamano1
			// 
			this->txtTamano1->Location = System::Drawing::Point(81, 36);
			this->txtTamano1->Name = L"txtTamano1";
			this->txtTamano1->Size = System::Drawing::Size(100, 20);
			this->txtTamano1->TabIndex = 1;
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Location = System::Drawing::Point(240, 39);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(46, 13);
			this->label2->TabIndex = 2;
			this->label2->Text = L"Tamano";
			this->label2->Click += gcnew System::EventHandler(this, &Form1::label2_Click);
			// 
			// txtTamano2
			// 
			this->txtTamano2->Location = System::Drawing::Point(301, 36);
			this->txtTamano2->Name = L"txtTamano2";
			this->txtTamano2->Size = System::Drawing::Size(100, 20);
			this->txtTamano2->TabIndex = 3;
			// 
			// btnIngresar
			// 
			this->btnIngresar->Location = System::Drawing::Point(65, 73);
			this->btnIngresar->Name = L"btnIngresar";
			this->btnIngresar->Size = System::Drawing::Size(75, 23);
			this->btnIngresar->TabIndex = 4;
			this->btnIngresar->Text = L"Ingresar";
			this->btnIngresar->UseVisualStyleBackColor = true;
			this->btnIngresar->Click += gcnew System::EventHandler(this, &Form1::btnIngresar_Click);
			// 
			// btnIngresar2
			// 
			this->btnIngresar2->Location = System::Drawing::Point(279, 73);
			this->btnIngresar2->Name = L"btnIngresar2";
			this->btnIngresar2->Size = System::Drawing::Size(75, 23);
			this->btnIngresar2->TabIndex = 5;
			this->btnIngresar2->Text = L"Ingresar";
			this->btnIngresar2->UseVisualStyleBackColor = true;
			this->btnIngresar2->Click += gcnew System::EventHandler(this, &Form1::btnIngresar2_Click);
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->Location = System::Drawing::Point(26, 118);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(31, 13);
			this->label3->TabIndex = 6;
			this->label3->Text = L"Valor";
			// 
			// label4
			// 
			this->label4->AutoSize = true;
			this->label4->Location = System::Drawing::Point(240, 118);
			this->label4->Name = L"label4";
			this->label4->Size = System::Drawing::Size(31, 13);
			this->label4->TabIndex = 7;
			this->label4->Text = L"Valor";
			this->label4->Click += gcnew System::EventHandler(this, &Form1::label4_Click);
			// 
			// txtTamano3
			// 
			this->txtTamano3->Location = System::Drawing::Point(81, 118);
			this->txtTamano3->Name = L"txtTamano3";
			this->txtTamano3->Size = System::Drawing::Size(100, 20);
			this->txtTamano3->TabIndex = 8;
			// 
			// txtTamano4
			// 
			this->txtTamano4->Location = System::Drawing::Point(301, 115);
			this->txtTamano4->Name = L"txtTamano4";
			this->txtTamano4->Size = System::Drawing::Size(100, 20);
			this->txtTamano4->TabIndex = 9;
			// 
			// btnIngresar3
			// 
			this->btnIngresar3->Location = System::Drawing::Point(65, 157);
			this->btnIngresar3->Name = L"btnIngresar3";
			this->btnIngresar3->Size = System::Drawing::Size(75, 23);
			this->btnIngresar3->TabIndex = 10;
			this->btnIngresar3->Text = L"Ingresar";
			this->btnIngresar3->UseVisualStyleBackColor = true;
			this->btnIngresar3->Click += gcnew System::EventHandler(this, &Form1::btnIngresar3_Click);
			// 
			// btnIngresar4
			// 
			this->btnIngresar4->Location = System::Drawing::Point(279, 157);
			this->btnIngresar4->Name = L"btnIngresar4";
			this->btnIngresar4->Size = System::Drawing::Size(75, 23);
			this->btnIngresar4->TabIndex = 11;
			this->btnIngresar4->Text = L"Ingresar";
			this->btnIngresar4->UseVisualStyleBackColor = true;
			this->btnIngresar4->Click += gcnew System::EventHandler(this, &Form1::btnIngresar4_Click);
			// 
			// grilla1
			// 
			this->grilla1->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->grilla1->Columns->AddRange(gcnew cli::array< System::Windows::Forms::DataGridViewColumn^  >(1) {this->Column1});
			this->grilla1->Location = System::Drawing::Point(12, 194);
			this->grilla1->Name = L"grilla1";
			this->grilla1->Size = System::Drawing::Size(240, 150);
			this->grilla1->TabIndex = 12;
			// 
			// Column1
			// 
			this->Column1->HeaderText = L"Column1";
			this->Column1->Name = L"Column1";
			// 
			// grilla2
			// 
			this->grilla2->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->grilla2->Columns->AddRange(gcnew cli::array< System::Windows::Forms::DataGridViewColumn^  >(1) {this->Column2});
			this->grilla2->Location = System::Drawing::Point(275, 194);
			this->grilla2->Name = L"grilla2";
			this->grilla2->Size = System::Drawing::Size(240, 150);
			this->grilla2->TabIndex = 13;
			// 
			// Column2
			// 
			this->Column2->HeaderText = L"Column2";
			this->Column2->Name = L"Column2";
			// 
			// grilla3
			// 
			this->grilla3->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->grilla3->Columns->AddRange(gcnew cli::array< System::Windows::Forms::DataGridViewColumn^  >(1) {this->Column3});
			this->grilla3->Location = System::Drawing::Point(533, 61);
			this->grilla3->Name = L"grilla3";
			this->grilla3->Size = System::Drawing::Size(240, 150);
			this->grilla3->TabIndex = 14;
			// 
			// Column3
			// 
			this->Column3->HeaderText = L"Column3";
			this->Column3->Name = L"Column3";
			// 
			// btnIntercalar
			// 
			this->btnIntercalar->Location = System::Drawing::Point(629, 29);
			this->btnIntercalar->Name = L"btnIntercalar";
			this->btnIntercalar->Size = System::Drawing::Size(75, 23);
			this->btnIntercalar->TabIndex = 15;
			this->btnIntercalar->Text = L"Intercalar";
			this->btnIntercalar->UseVisualStyleBackColor = true;
			this->btnIntercalar->Click += gcnew System::EventHandler(this, &Form1::btnIntercalar_Click);
			// 
			// Form1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(785, 356);
			this->Controls->Add(this->btnIntercalar);
			this->Controls->Add(this->grilla3);
			this->Controls->Add(this->grilla2);
			this->Controls->Add(this->grilla1);
			this->Controls->Add(this->btnIngresar4);
			this->Controls->Add(this->btnIngresar3);
			this->Controls->Add(this->txtTamano4);
			this->Controls->Add(this->txtTamano3);
			this->Controls->Add(this->label4);
			this->Controls->Add(this->label3);
			this->Controls->Add(this->btnIngresar2);
			this->Controls->Add(this->btnIngresar);
			this->Controls->Add(this->txtTamano2);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->txtTamano1);
			this->Controls->Add(this->label1);
			this->Name = L"Form1";
			this->Text = L"Form1";
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->grilla1))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->grilla2))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->grilla3))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void label2_Click(System::Object^  sender, System::EventArgs^  e) {
			 }
private: System::Void label4_Click(System::Object^  sender, System::EventArgs^  e) {
		 }

private: System::Void btnIngresar_Click(System::Object^  sender, System::EventArgs^  e) {
			 int Tam1;
				 Tam1=System::Convert::ToInt32(txtTamano1->Text);
				 In3.Set_tamano(Tam1);
				 In1.Set_tamano(Tam1);
				 grilla1->RowCount=In1.Get_tamano();
				 
				 pos=0;
		 }
private: System::Void btnIngresar2_Click(System::Object^  sender, System::EventArgs^  e) {
			  int Tam2,Tam1;
				 Tam2=System::Convert::ToInt32(txtTamano2->Text);
				 Tam1=System::Convert::ToInt32(txtTamano1->Text);
				 In2.Set_tamano(Tam2);
				 In3.Set_tamano(Tam1+Tam2);
				
				 grilla2->RowCount=In2.Get_tamano();
				 pos=0;
		 }
private: System::Void btnIngresar3_Click(System::Object^  sender, System::EventArgs^  e) {
			  double elem1;
			 elem1=System::Convert::ToDouble(txtTamano3->Text);
			
			 if(In1.Llenar(pos,elem1))
			 {	 In1.Set_vector(pos,elem1);
				 pos++;
				 grilla1->ColumnCount=1;
				 grilla1->ColumnCount=In1.Get_tamano();
				 double val1;
				 for(int i=0;i<In1.Get_tamano();i++)
				 {
					
					 val1=In1.Get_vector(i);
				
					 grilla1->Rows[i]->Cells[0]->Value=System::Convert::ToDouble(val1);
					 
					 
				 }
			 }
		 }
private: System::Void btnIngresar4_Click(System::Object^  sender, System::EventArgs^  e) {
			  double elem2;
			 elem2=System::Convert::ToDouble(txtTamano4->Text);
			 if(In2.Llenar(pos,elem2))
			 { 
In2.Set_vector(pos,elem2);
			 	 pos++;
				 grilla2->ColumnCount=1;
				 grilla2->ColumnCount=In2.Get_tamano();
				 double val2;
				 for(int i=0;i<In2.Get_tamano();i++)
				 {
					 val2=In2.Get_vector(i);
					 grilla2->Rows[i]->Cells[0]->Value=System::Convert::ToDouble(val2);
					 }
			 }
		 }
		 private: System::Void btnIntercalar_Click(System::Object^  sender, System::EventArgs^  e) {
			 int Tam1,Tam2,Tam3;
			 Tam1= System::Convert::ToInt32(txtTamano1->Text);
			 Tam2= System::Convert::ToInt32(txtTamano2->Text);
			 Tam3= Tam1+Tam2;
			 In3.Set_tamano(Tam3);
			 grilla3->RowCount=In3.Get_tamano();
			 In3=In3.Concatenar(In1,In2);
				 for(int i=0; i<In3; i++)
				 {
					 grilla3->Rows[i]->Cells[0]->Value=System::Convert::ToDouble(In3.Get_vector);
				 }
		 }
};
}

