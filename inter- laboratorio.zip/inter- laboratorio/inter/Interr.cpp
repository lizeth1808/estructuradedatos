#include "StdAfx.h"
#include "Interr.h"


Interr::Interr(void)
{
}
int Interr::Get_tamano()
{
	return tamano;
}
void Interr::Set_tamano(int tam)
{
	tamano=tam;
}
double Interr::Get_vector(int posicion)
{
	return vec[posicion];
}
void Interr::Set_vector(int posicion, double elemento)
{
	vec[posicion]=elemento;
}
bool Interr::Llenar()
{
	if(tamano==M-1)
	{return true;}
	else{return false;}
}
bool Interr::VacioVector()
{
	if(tamano==0)
	{return true;}
	else{return false;}
}
bool Interr::Llenar(int posicion, double elemento)
{
	if((posicion<0)&&(posicion>tamano))
	{return false;}
	else
		{
			if(LlenoVector()==true)
			{return false;}
			else
				{
					int i=Get_tamano();
					while(i>posicion)
					{
						vec[i]=vec[i-1];
						i--;
					}
					vec[i]=elemento;
					return true;
				}

		}
}
Interr Interr::Concatenar(Interr vec1, Interr vec2)
{
	Interr vec3;
	vec3.tamano=vec1.tamano+vec2.tamano;
	for(int i=0; i<vec1.tamano;i++)
	{
		vec3.vec[i]=vec1.vec[i];
	}for(int k=vec1.tamano; k<vec3.tamano;k++)
	{
		vec3.vec[k]=vec2.vec[k-vec1.tamano];
	}
	double aux;

	for( int a=0;a<vec3.tamano;a++)
	{
		for(int b=a+1; b<vec3.tamano;b++)
		{ 
			if(vec3.vec[b]<vec3.vec[a])
			{
				aux=vec3.vec[a];
				vec3.vec[a]=vec3.vec[b];
				vec3.vec[b]=aux;
			}
		}
	}
}
