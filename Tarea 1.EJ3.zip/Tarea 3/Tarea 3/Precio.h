#pragma once

using namespace std;

 class Precio
{
private:
	double preciototal;
	int unidades;
	double preciounitario;
public:
	Precio(void);
double Get_preciototal();
void Set_preciototal(double pretot);
int Get_unidades();
void Set_unidades( int uni);
void Calcular(Precio p, Precio u);
int divi(); 
};

