#pragma once
#include <iostream>
#include "Precio.h"
#include <string>
#include <msclr\marshal_cppstd.h>

namespace Tarea3 {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace std;
	using namespace msclr::interop;
	/// <summary>
	/// Summary for Form1
	/// </summary>
	public ref class Form1 : public System::Windows::Forms::Form
	{
	public:
		Form1(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Label^  label1;
	protected: 
	private: System::Windows::Forms::Label^  label2;
	private: System::Windows::Forms::Label^  label3;
	private: System::Windows::Forms::TextBox^  txtTotal;
	private: System::Windows::Forms::TextBox^  txtUnidades;
	private: System::Windows::Forms::TextBox^  txtUnitario;
	private: System::Windows::Forms::Button^  btnCalcular;

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->txtTotal = (gcnew System::Windows::Forms::TextBox());
			this->txtUnidades = (gcnew System::Windows::Forms::TextBox());
			this->txtUnitario = (gcnew System::Windows::Forms::TextBox());
			this->btnCalcular = (gcnew System::Windows::Forms::Button());
			this->SuspendLayout();
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Location = System::Drawing::Point(47, 22);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(60, 13);
			this->label1->TabIndex = 0;
			this->label1->Text = L"Precio total";
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Location = System::Drawing::Point(47, 68);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(52, 13);
			this->label2->TabIndex = 1;
			this->label2->Text = L"Unidades";
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->Location = System::Drawing::Point(47, 115);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(74, 13);
			this->label3->TabIndex = 2;
			this->label3->Text = L"Precio unitario";
			// 
			// txtTotal
			// 
			this->txtTotal->Location = System::Drawing::Point(127, 15);
			this->txtTotal->Name = L"txtTotal";
			this->txtTotal->Size = System::Drawing::Size(100, 20);
			this->txtTotal->TabIndex = 3;
			// 
			// txtUnidades
			// 
			this->txtUnidades->Location = System::Drawing::Point(127, 61);
			this->txtUnidades->Name = L"txtUnidades";
			this->txtUnidades->Size = System::Drawing::Size(100, 20);
			this->txtUnidades->TabIndex = 4;
			// 
			// txtUnitario
			// 
			this->txtUnitario->Location = System::Drawing::Point(127, 108);
			this->txtUnitario->Name = L"txtUnitario";
			this->txtUnitario->Size = System::Drawing::Size(100, 20);
			this->txtUnitario->TabIndex = 5;
			// 
			// btnCalcular
			// 
			this->btnCalcular->Location = System::Drawing::Point(92, 187);
			this->btnCalcular->Name = L"btnCalcular";
			this->btnCalcular->Size = System::Drawing::Size(75, 23);
			this->btnCalcular->TabIndex = 6;
			this->btnCalcular->Text = L"Calcular";
			this->btnCalcular->UseVisualStyleBackColor = true;
			this->btnCalcular->Click += gcnew System::EventHandler(this, &Form1::btnCalcular_Click);
			// 
			// Form1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(284, 261);
			this->Controls->Add(this->btnCalcular);
			this->Controls->Add(this->txtUnitario);
			this->Controls->Add(this->txtUnidades);
			this->Controls->Add(this->txtTotal);
			this->Controls->Add(this->label3);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->label1);
			this->Name = L"Form1";
			this->Text = L"Form1";
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void btnCalcular_Click(System::Object^  sender, System::EventArgs^  e) {
				 Precio precio;
				 precio.Set_preciototal(System::Convert::ToDouble(txtTotal->Text));
				 precio.Set_unidades(System::Convert::ToInt32(txtUnidades->Text));
				 double division;
				 division= precio.Get_preciototal()/precio.Get_unidades();
				 txtUnitario->Text= System::Convert::ToString(division);
			 }
};
}

