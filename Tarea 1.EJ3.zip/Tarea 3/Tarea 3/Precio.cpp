#include "StdAfx.h"
#include "Precio.h"
#include <iostream>


Precio::Precio(void)
{
}
double Precio::Get_preciototal()
{
	return preciototal;
}
void Precio::Set_preciototal(double pretot)
{
	preciototal= pretot;
}
int Precio::Get_unidades()
{
	return unidades;
}
void Precio::Set_unidades( int uni)
{
	unidades= uni;
}
void Precio::Calcular(Precio p, Precio u)
{
	preciounitario= p.preciototal/u.unidades;
}
int Precio::divi()
{
	return preciounitario;
}
