#pragma once
#include <iostream>
#include <string>
using namespace std;
class Numeros
{private:
		int numero;
public:
	Numeros(void);
	int Get_numero();
	void Set_numero( int num);
	string convertir();
	
};

