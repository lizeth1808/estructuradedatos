#pragma once
#include "stdafx.h"
#include <iostream>
#include "Numeros.h"
#include <string>
#include <msclr\marshal_cppstd.h>



namespace ejer7 {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace std;
	using namespace msclr::interop;

	/// <summary>
	/// Summary for Form1
	/// </summary>
	Numeros numeros;
	public ref class Form1 : public System::Windows::Forms::Form
	{
	public:
		Form1(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Label^  label1;
	protected: 
	private: System::Windows::Forms::Button^  btnConvertir;
	private: System::Windows::Forms::TextBox^  txtNum;
	private: System::Windows::Forms::TextBox^  txtConver;
	private: System::Windows::Forms::Button^  btnColocar;

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->btnConvertir = (gcnew System::Windows::Forms::Button());
			this->txtNum = (gcnew System::Windows::Forms::TextBox());
			this->txtConver = (gcnew System::Windows::Forms::TextBox());
			this->btnColocar = (gcnew System::Windows::Forms::Button());
			this->SuspendLayout();
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Location = System::Drawing::Point(35, 39);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(44, 13);
			this->label1->TabIndex = 0;
			this->label1->Text = L"Numero";
			// 
			// btnConvertir
			// 
			this->btnConvertir->Location = System::Drawing::Point(17, 83);
			this->btnConvertir->Name = L"btnConvertir";
			this->btnConvertir->Size = System::Drawing::Size(75, 23);
			this->btnConvertir->TabIndex = 1;
			this->btnConvertir->Text = L"Convertir";
			this->btnConvertir->UseVisualStyleBackColor = true;
			this->btnConvertir->Click += gcnew System::EventHandler(this, &Form1::btnConvertir_Click);
			// 
			// txtNum
			// 
			this->txtNum->Location = System::Drawing::Point(98, 32);
			this->txtNum->Name = L"txtNum";
			this->txtNum->Size = System::Drawing::Size(100, 20);
			this->txtNum->TabIndex = 2;
			// 
			// txtConver
			// 
			this->txtConver->Location = System::Drawing::Point(98, 83);
			this->txtConver->Name = L"txtConver";
			this->txtConver->Size = System::Drawing::Size(100, 20);
			this->txtConver->TabIndex = 3;
			// 
			// btnColocar
			// 
			this->btnColocar->Location = System::Drawing::Point(204, 32);
			this->btnColocar->Name = L"btnColocar";
			this->btnColocar->Size = System::Drawing::Size(75, 23);
			this->btnColocar->TabIndex = 4;
			this->btnColocar->Text = L"Colocar numero";
			this->btnColocar->UseVisualStyleBackColor = true;
			this->btnColocar->Click += gcnew System::EventHandler(this, &Form1::btnColocar_Click);
			// 
			// Form1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(284, 261);
			this->Controls->Add(this->btnColocar);
			this->Controls->Add(this->txtConver);
			this->Controls->Add(this->txtNum);
			this->Controls->Add(this->btnConvertir);
			this->Controls->Add(this->label1);
			this->Name = L"Form1";
			this->Text = L"Form1";
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
			private: System::Void btnColocar_Click(System::Object^  sender, System::EventArgs^  e) {
						 numeros.Set_numero(System::Convert::ToInt32(txtNum->Text));
			 }

	private: System::Void btnConvertir_Click(System::Object^  sender, System::EventArgs^  e) {
				 string r;
				 r= numeros.convertir();
				 txtConver->Text=marshal_as<System::String^>(r);
			 }
};
}

