#pragma once
#include "Pila.h"

using namespace std;
using namespace System::Windows::Forms;
class Operaciones:public Pila
{
public:
	Operaciones(void);
	void Guardar_Pila(DataGridView^ Grilla);
	void Insertar_Elemento(TextBox^ Valor, TextBox^ valor);
	void Mostrar_Pila(DataGridView^ Grilla);
};

