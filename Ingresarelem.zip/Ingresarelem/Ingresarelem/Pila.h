#pragma once
#define N 6
class Pila
{
private:
	int tope;
	int V[N];
public:
	Pila(void);
	int Get_tope();
	bool Vacia();
	bool Llena();
	bool Insertar(int x);
	bool Eliminar(int &x);
};

