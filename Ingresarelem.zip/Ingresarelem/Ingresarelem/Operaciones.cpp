#include "StdAfx.h"
#include "Operaciones.h"


Operaciones::Operaciones(void)
{
	Pila();
	int pos=0;
	
}
void Operaciones::Guardar_Pila(DataGridView^ Grilla)
{
	
	}
}
void Operaciones::Insertar_Elemento(TextBox^ Valor, TextBox^ valor, DataGridView^ Grilla)
{
	
	
		
void Operaciones::Mostrar_Pila(DataGridView^ Grilla)
{
	Grilla->RowCount= Pila::Get_tope()+2;
	int i=0;
	int elem;
	while(aux.Vacia()==false)
	{
		Pila::ins(elem);
		aux.Insertar(elem);
		Grilla->Rows[i]->Cells[0]->Value= elem;
		i++;

	}
}
