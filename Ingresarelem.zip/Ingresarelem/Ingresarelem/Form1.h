#pragma once
#include "Pila.h"
#include "Operaciones.h"

namespace Ingresarelem {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace std;

	Pila P
	Operaciones O;
	int pos=0;
	/// <summary>
	/// Summary for Form1
	/// </summary>
	public ref class Form1 : public System::Windows::Forms::Form
	{
	public:
		Form1(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::TextBox^  txtTam;
	protected: 
	private: System::Windows::Forms::TextBox^  txtElem;
	private: System::Windows::Forms::Button^  btnTam;
	private: System::Windows::Forms::Button^  Insertar;
	private: System::Windows::Forms::Button^  btnElem;
	private: System::Windows::Forms::Button^  btnMostrar;
	private: System::Windows::Forms::DataGridView^  Grid1;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  Column1;
	private: System::Windows::Forms::DataGridView^  Grid2;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  Column2;

	private: System::Windows::Forms::TextBox^  txtNum;
	private: System::Windows::Forms::Label^  label1;

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->txtTam = (gcnew System::Windows::Forms::TextBox());
			this->txtElem = (gcnew System::Windows::Forms::TextBox());
			this->btnTam = (gcnew System::Windows::Forms::Button());
			this->Insertar = (gcnew System::Windows::Forms::Button());
			this->btnElem = (gcnew System::Windows::Forms::Button());
			this->btnMostrar = (gcnew System::Windows::Forms::Button());
			this->Grid1 = (gcnew System::Windows::Forms::DataGridView());
			this->Column1 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->Grid2 = (gcnew System::Windows::Forms::DataGridView());
			this->Column2 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->txtNum = (gcnew System::Windows::Forms::TextBox());
			this->label1 = (gcnew System::Windows::Forms::Label());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->Grid1))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->Grid2))->BeginInit();
			this->SuspendLayout();
			// 
			// txtTam
			// 
			this->txtTam->Location = System::Drawing::Point(51, 12);
			this->txtTam->Name = L"txtTam";
			this->txtTam->Size = System::Drawing::Size(100, 20);
			this->txtTam->TabIndex = 0;
			// 
			// txtElem
			// 
			this->txtElem->Location = System::Drawing::Point(51, 63);
			this->txtElem->Name = L"txtElem";
			this->txtElem->Size = System::Drawing::Size(100, 20);
			this->txtElem->TabIndex = 1;
			// 
			// btnTam
			// 
			this->btnTam->Location = System::Drawing::Point(207, 12);
			this->btnTam->Name = L"btnTam";
			this->btnTam->Size = System::Drawing::Size(75, 23);
			this->btnTam->TabIndex = 2;
			this->btnTam->Text = L"Tamano";
			this->btnTam->UseVisualStyleBackColor = true;
			this->btnTam->Click += gcnew System::EventHandler(this, &Form1::btnTam_Click);
			// 
			// Insertar
			// 
			this->Insertar->Location = System::Drawing::Point(6, 195);
			this->Insertar->Name = L"Insertar";
			this->Insertar->Size = System::Drawing::Size(75, 23);
			this->Insertar->TabIndex = 3;
			this->Insertar->Text = L"Insertar";
			this->Insertar->UseVisualStyleBackColor = true;
			this->Insertar->Click += gcnew System::EventHandler(this, &Form1::Insertar_Click);
			// 
			// btnElem
			// 
			this->btnElem->Location = System::Drawing::Point(207, 60);
			this->btnElem->Name = L"btnElem";
			this->btnElem->Size = System::Drawing::Size(75, 23);
			this->btnElem->TabIndex = 4;
			this->btnElem->Text = L"Posicion";
			this->btnElem->UseVisualStyleBackColor = true;
			this->btnElem->Click += gcnew System::EventHandler(this, &Form1::btnElem_Click);
			// 
			// btnMostrar
			// 
			this->btnMostrar->Location = System::Drawing::Point(428, 91);
			this->btnMostrar->Name = L"btnMostrar";
			this->btnMostrar->Size = System::Drawing::Size(75, 23);
			this->btnMostrar->TabIndex = 5;
			this->btnMostrar->Text = L"Mostrar";
			this->btnMostrar->UseVisualStyleBackColor = true;
			this->btnMostrar->Click += gcnew System::EventHandler(this, &Form1::btnMostrar_Click);
			// 
			// Grid1
			// 
			this->Grid1->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->Grid1->Columns->AddRange(gcnew cli::array< System::Windows::Forms::DataGridViewColumn^  >(1) {this->Column1});
			this->Grid1->Location = System::Drawing::Point(87, 142);
			this->Grid1->Name = L"Grid1";
			this->Grid1->Size = System::Drawing::Size(240, 150);
			this->Grid1->TabIndex = 6;
			// 
			// Column1
			// 
			this->Column1->HeaderText = L"Column1";
			this->Column1->Name = L"Column1";
			// 
			// Grid2
			// 
			this->Grid2->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->Grid2->Columns->AddRange(gcnew cli::array< System::Windows::Forms::DataGridViewColumn^  >(1) {this->Column2});
			this->Grid2->Location = System::Drawing::Point(365, 142);
			this->Grid2->Name = L"Grid2";
			this->Grid2->Size = System::Drawing::Size(240, 150);
			this->Grid2->TabIndex = 7;
			// 
			// Column2
			// 
			this->Column2->HeaderText = L"Column2";
			this->Column2->Name = L"Column2";
			// 
			// txtNum
			// 
			this->txtNum->Location = System::Drawing::Point(51, 91);
			this->txtNum->Name = L"txtNum";
			this->txtNum->Size = System::Drawing::Size(100, 20);
			this->txtNum->TabIndex = 9;
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Location = System::Drawing::Point(204, 96);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(44, 13);
			this->label1->TabIndex = 10;
			this->label1->Text = L"Numero";
			// 
			// Form1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(658, 304);
			this->Controls->Add(this->label1);
			this->Controls->Add(this->txtNum);
			this->Controls->Add(this->Grid2);
			this->Controls->Add(this->Grid1);
			this->Controls->Add(this->btnMostrar);
			this->Controls->Add(this->btnElem);
			this->Controls->Add(this->Insertar);
			this->Controls->Add(this->btnTam);
			this->Controls->Add(this->txtElem);
			this->Controls->Add(this->txtTam);
			this->Name = L"Form1";
			this->Text = L"Form1";
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->Grid1))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->Grid2))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void btnTam_Click(System::Object^  sender, System::EventArgs^  e) {
				 int elem;
				 elem= System::Convert::ToInt32(txtTam->Text);
				 Grid1->RowCount=elem;
			 }
private: System::Void Insertar_Click(System::Object^  sender, System::EventArgs^  e) {
			 int i=0;
	
       	while(i<Grilla->RowCount-1)
	    {
		   P.Insertar(System::Convert::ToInt32(Grilla->Rows[i]->Cells[0]->Value));
		   i++;
		   pos++;
		 }
private: System::Void Numero_Click(System::Object^  sender, System::EventArgs^  e) {
		 }
private: System::Void btnElem_Click(System::Object^  sender, System::EventArgs^  e) 
		 {
			 Pila aux;
	         int elem;
	         int num;
             int posi;
	         posi= System::Convert::ToInt32(Valor->Text);
	         num= System::Convert::ToInt32(valor->Text);
           	while(posi<pos)
	        {
	        	P.Eliminar(elem);
	        	aux.Insertar(elem);
	         	Grid2->Rows[pos]->Cells[0]->Value(elem);
	        	pos--;
	        }
	
		     Grilla->Rows[pos]->Cells[0]->Value(num);

	while(aux.Vacia()==false)
	{
		aux.Eliminar(elem);
		P,Insertar(elem);
		pos++;
		 Grilla->Rows[pos]->Cells[0]->Value(elem);
		
	}
		 }
private: System::Void btnMostrar_Click(System::Object^  sender, System::EventArgs^  e) {
			 O.Mostrar_Pila(Grid2);
		 }
};
}

