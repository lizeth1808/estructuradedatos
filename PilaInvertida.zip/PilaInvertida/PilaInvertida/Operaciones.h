#pragma once
#include "Invertir.h"

using namespace std;
using namespace System::Windows::Forms;

class Operaciones:public Invertir
{
public:
	Operaciones(void);
	void Guardar_Pila(DataGridView^ Grilla);
	void Invertir_Pila(DataGridView^ Grilla);
};

