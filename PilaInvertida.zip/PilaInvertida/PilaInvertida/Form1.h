#pragma once
#include "Invertir.h"
#include "Operaciones.h"

namespace PilaInvertida {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace std;

	Operaciones O;
	/// <summary>
	/// Summary for Form1
	/// </summary>
	public ref class Form1 : public System::Windows::Forms::Form
	{
	public:
		Form1(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::TextBox^  txtTam;
	protected: 
	private: System::Windows::Forms::Button^  btnTam;
	private: System::Windows::Forms::DataGridView^  Grid1;

	private: System::Windows::Forms::DataGridViewTextBoxColumn^  Column1;
	private: System::Windows::Forms::Button^  button1;
	private: System::Windows::Forms::Button^  btnInvertir;
	private: System::Windows::Forms::DataGridView^  Grid2;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  Column2;

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->txtTam = (gcnew System::Windows::Forms::TextBox());
			this->btnTam = (gcnew System::Windows::Forms::Button());
			this->Grid1 = (gcnew System::Windows::Forms::DataGridView());
			this->Column1 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->button1 = (gcnew System::Windows::Forms::Button());
			this->btnInvertir = (gcnew System::Windows::Forms::Button());
			this->Grid2 = (gcnew System::Windows::Forms::DataGridView());
			this->Column2 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->Grid1))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->Grid2))->BeginInit();
			this->SuspendLayout();
			// 
			// txtTam
			// 
			this->txtTam->Location = System::Drawing::Point(53, 32);
			this->txtTam->Name = L"txtTam";
			this->txtTam->Size = System::Drawing::Size(100, 20);
			this->txtTam->TabIndex = 0;
			// 
			// btnTam
			// 
			this->btnTam->Location = System::Drawing::Point(205, 29);
			this->btnTam->Name = L"btnTam";
			this->btnTam->Size = System::Drawing::Size(75, 23);
			this->btnTam->TabIndex = 1;
			this->btnTam->Text = L"Tamano";
			this->btnTam->UseVisualStyleBackColor = true;
			this->btnTam->Click += gcnew System::EventHandler(this, &Form1::btnTam_Click);
			// 
			// Grid1
			// 
			this->Grid1->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->Grid1->Columns->AddRange(gcnew cli::array< System::Windows::Forms::DataGridViewColumn^  >(1) {this->Column1});
			this->Grid1->Location = System::Drawing::Point(53, 135);
			this->Grid1->Name = L"Grid1";
			this->Grid1->Size = System::Drawing::Size(240, 150);
			this->Grid1->TabIndex = 2;
			// 
			// Column1
			// 
			this->Column1->HeaderText = L"Column1";
			this->Column1->Name = L"Column1";
			// 
			// button1
			// 
			this->button1->Location = System::Drawing::Point(205, 73);
			this->button1->Name = L"button1";
			this->button1->Size = System::Drawing::Size(75, 23);
			this->button1->TabIndex = 3;
			this->button1->Text = L"Insertar";
			this->button1->UseVisualStyleBackColor = true;
			this->button1->Click += gcnew System::EventHandler(this, &Form1::button1_Click);
			// 
			// btnInvertir
			// 
			this->btnInvertir->Location = System::Drawing::Point(424, 73);
			this->btnInvertir->Name = L"btnInvertir";
			this->btnInvertir->Size = System::Drawing::Size(75, 23);
			this->btnInvertir->TabIndex = 4;
			this->btnInvertir->Text = L"Invertir";
			this->btnInvertir->UseVisualStyleBackColor = true;
			this->btnInvertir->Click += gcnew System::EventHandler(this, &Form1::btnInvertir_Click);
			// 
			// Grid2
			// 
			this->Grid2->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->Grid2->Columns->AddRange(gcnew cli::array< System::Windows::Forms::DataGridViewColumn^  >(1) {this->Column2});
			this->Grid2->Location = System::Drawing::Point(359, 135);
			this->Grid2->Name = L"Grid2";
			this->Grid2->Size = System::Drawing::Size(240, 150);
			this->Grid2->TabIndex = 5;
			// 
			// Column2
			// 
			this->Column2->HeaderText = L"Column2";
			this->Column2->Name = L"Column2";
			// 
			// Form1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(657, 314);
			this->Controls->Add(this->Grid2);
			this->Controls->Add(this->btnInvertir);
			this->Controls->Add(this->button1);
			this->Controls->Add(this->Grid1);
			this->Controls->Add(this->btnTam);
			this->Controls->Add(this->txtTam);
			this->Name = L"Form1";
			this->Text = L"Form1";
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->Grid1))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->Grid2))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void btnTam_Click(System::Object^  sender, System::EventArgs^  e) {
				 int el;
				 el= System::Convert::ToInt32(txtTam->Text);
				 Grid1->RowCount= el;
			 }
			 
	private: System::Void button1_Click(System::Object^  sender, System::EventArgs^  e) {
				 O.Guardar_Pila(Grid1);

			 }
private: System::Void btnInvertir_Click(System::Object^  sender, System::EventArgs^  e) {
			 O.Invertir_Pila(Grid2);
		 }
};
}

