#pragma once
#define N 6
class Invertir
{
private:
	int V[N];
	int tope;
public:
	Invertir(void);
	int Get_tope();
	bool Vacia();
	bool Llena();
	bool Insertar(int x);
	bool Eliminar(int &x);
};

