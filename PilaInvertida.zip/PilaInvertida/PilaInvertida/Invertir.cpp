#include "StdAfx.h"
#include "Invertir.h"


Invertir::Invertir(void)
{
	tope=-1;
}
bool Invertir::Vacia()
{
	if(tope==-1)
		return true;
	else
		return false;
}
bool Invertir::Llena()
{
	if(tope==N)
		return true;
	else
		return false;

}
	bool Invertir::Insertar(int x)
	{
		if(Llena()==true)
			return false;
		else 
		{
			V[++tope]=x;
			return true;
		}
	}
	bool Invertir::Eliminar(int &x)
	{
		if(Vacia()==true)
			return false;
		else
			{x= V[tope--];
			return true;
		}
	}
	int Invertir::Get_tope()
	{
		return tope;
	}