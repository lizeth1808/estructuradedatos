#include "StdAfx.h"
#include "Operaciones.h"
#include "Invertir.h"


Operaciones::Operaciones(void)
{
	Invertir();
}
	void Operaciones::Guardar_Pila(DataGridView^ Grilla)
	{
		int i=0;
		while(i<Grilla->RowCount-1)
		{
			Invertir::Insertar(System::Convert::ToInt32(Grilla->Rows[i]->Cells[0]->Value));
			i++;
		}

	}
	void Operaciones::Invertir_Pila(DataGridView^ Grilla)
	{
		Grilla->RowCount= Invertir::Get_tope()+1;
		Invertir aux1,aux2;
		int elem;
		while(Invertir::Vacia()==false)
		{
		 Invertir::Eliminar(elem);
		 aux1.Insertar(elem);
		}
		int i=0;
		while(aux1.Vacia()==false)
		{
			aux1.Eliminar(elem);
			aux2.Insertar(elem);
			Grilla->Rows[i]->Cells[0]->Value= elem;
			i++;
		}
		while(aux2.Vacia()==false)
		{
			aux2.Eliminar(elem);
			Invertir::Insertar(elem);
		}

	}

