#pragma once

namespace areadecuadrado {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// Summary for Form1
	/// </summary>
	public ref class Form1 : public System::Windows::Forms::Form
	{
	public:
		Form1(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::TextBox^  txtlado;
	protected: 

	protected: 
	private: System::Windows::Forms::Label^  label1;
	private: System::Windows::Forms::Label^  label2;
	private: System::Windows::Forms::TextBox^  txtarea;
	private: System::Windows::Forms::Button^  btbcalcular;



	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			System::ComponentModel::ComponentResourceManager^  resources = (gcnew System::ComponentModel::ComponentResourceManager(Form1::typeid));
			this->txtlado = (gcnew System::Windows::Forms::TextBox());
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->txtarea = (gcnew System::Windows::Forms::TextBox());
			this->btbcalcular = (gcnew System::Windows::Forms::Button());
			this->SuspendLayout();
			// 
			// txtlado
			// 
			resources->ApplyResources(this->txtlado, L"txtlado");
			this->txtlado->Name = L"txtlado";
			this->txtlado->TextChanged += gcnew System::EventHandler(this, &Form1::txtlado_TextChanged);
			// 
			// label1
			// 
			resources->ApplyResources(this->label1, L"label1");
			this->label1->Name = L"label1";
			this->label1->Click += gcnew System::EventHandler(this, &Form1::label1_Click);
			// 
			// label2
			// 
			resources->ApplyResources(this->label2, L"label2");
			this->label2->Name = L"label2";
			// 
			// txtarea
			// 
			resources->ApplyResources(this->txtarea, L"txtarea");
			this->txtarea->Name = L"txtarea";
			// 
			// btbcalcular
			// 
			resources->ApplyResources(this->btbcalcular, L"btbcalcular");
			this->btbcalcular->Name = L"btbcalcular";
			this->btbcalcular->UseVisualStyleBackColor = true;
			this->btbcalcular->Click += gcnew System::EventHandler(this, &Form1::btbcalcular_Click);
			// 
			// Form1
			// 
			resources->ApplyResources(this, L"$this");
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->Controls->Add(this->btbcalcular);
			this->Controls->Add(this->txtarea);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->label1);
			this->Controls->Add(this->txtlado);
			this->Name = L"Form1";
			this->Load += gcnew System::EventHandler(this, &Form1::Form1_Load);
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void Form1_Load(System::Object^  sender, System::EventArgs^  e) {
			 }
private: System::Void label1_Click(System::Object^  sender, System::EventArgs^  e) {
		 }
private: System::Void btbcalcular_Click(System::Object^  sender, System::EventArgs^  e) {
			 int Lado,Area;
			 Lado= System::Convert::ToInt32(txtlado->Text);
				 Area = Lado*Lado;
				 txtarea->Text = Area.ToString();
		 }
private: System::Void txtlado_TextChanged(System::Object^  sender, System::EventArgs^  e) {
		 }
};
}

