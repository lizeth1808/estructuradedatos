#pragma once
#include "stdafx.h"
#include <iostream>
#include <string>
#include <msclr\marshal_cppstd.h>

using namespace std;

#define n 50

class Examen
{
private:
	int vec[n];
	int Tamano;
public:
	Examen(void);
	int Get_Tamano();
	void Set_Tamano(int tam);
	int Get_Vector(int posicion);
	void Set_Vector(int posicion, int elemento);
	bool Calcular(int t, int x);

};

