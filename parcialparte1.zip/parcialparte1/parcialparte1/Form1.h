#pragma once
#include "Examen.h"

namespace parcialparte1 {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace std;
	using namespace msclr::interop;

	Examen e1;
	int pos=0;

	/// <summary>
	/// Summary for Form1
	/// </summary>
	public ref class Form1 : public System::Windows::Forms::Form
	{
	public:
		Form1(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Label^  label1;
	protected: 
	private: System::Windows::Forms::Label^  label2;
	private: System::Windows::Forms::TextBox^  txtTam;
	private: System::Windows::Forms::TextBox^  txtNum;
	private: System::Windows::Forms::Button^  btnTam;
	private: System::Windows::Forms::Button^  button2;
	private: System::Windows::Forms::DataGridView^  Grid1;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  Column1;
	private: System::Windows::Forms::DataGridView^  Grid2;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  Column2;
	private: System::Windows::Forms::Button^  btnVer;

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->txtTam = (gcnew System::Windows::Forms::TextBox());
			this->txtNum = (gcnew System::Windows::Forms::TextBox());
			this->btnTam = (gcnew System::Windows::Forms::Button());
			this->button2 = (gcnew System::Windows::Forms::Button());
			this->Grid1 = (gcnew System::Windows::Forms::DataGridView());
			this->Column1 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->Grid2 = (gcnew System::Windows::Forms::DataGridView());
			this->Column2 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->btnVer = (gcnew System::Windows::Forms::Button());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->Grid1))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->Grid2))->BeginInit();
			this->SuspendLayout();
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Location = System::Drawing::Point(56, 43);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(46, 13);
			this->label1->TabIndex = 0;
			this->label1->Text = L"Tamano";
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Location = System::Drawing::Point(56, 82);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(49, 13);
			this->label2->TabIndex = 1;
			this->label2->Text = L"Numeros";
			// 
			// txtTam
			// 
			this->txtTam->Location = System::Drawing::Point(118, 40);
			this->txtTam->Name = L"txtTam";
			this->txtTam->Size = System::Drawing::Size(100, 20);
			this->txtTam->TabIndex = 2;
			// 
			// txtNum
			// 
			this->txtNum->Location = System::Drawing::Point(118, 75);
			this->txtNum->Name = L"txtNum";
			this->txtNum->Size = System::Drawing::Size(100, 20);
			this->txtNum->TabIndex = 3;
			// 
			// btnTam
			// 
			this->btnTam->Location = System::Drawing::Point(254, 37);
			this->btnTam->Name = L"btnTam";
			this->btnTam->Size = System::Drawing::Size(75, 23);
			this->btnTam->TabIndex = 4;
			this->btnTam->Text = L"Ingresar";
			this->btnTam->UseVisualStyleBackColor = true;
			this->btnTam->Click += gcnew System::EventHandler(this, &Form1::btnTam_Click);
			// 
			// button2
			// 
			this->button2->Location = System::Drawing::Point(254, 72);
			this->button2->Name = L"button2";
			this->button2->Size = System::Drawing::Size(75, 23);
			this->button2->TabIndex = 5;
			this->button2->Text = L"Ingresar";
			this->button2->UseVisualStyleBackColor = true;
			this->button2->Click += gcnew System::EventHandler(this, &Form1::button2_Click);
			// 
			// Grid1
			// 
			this->Grid1->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->Grid1->Columns->AddRange(gcnew cli::array< System::Windows::Forms::DataGridViewColumn^  >(1) {this->Column1});
			this->Grid1->Location = System::Drawing::Point(39, 133);
			this->Grid1->Name = L"Grid1";
			this->Grid1->Size = System::Drawing::Size(240, 150);
			this->Grid1->TabIndex = 6;
			// 
			// Column1
			// 
			this->Column1->HeaderText = L"Vector";
			this->Column1->Name = L"Column1";
			// 
			// Grid2
			// 
			this->Grid2->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->Grid2->Columns->AddRange(gcnew cli::array< System::Windows::Forms::DataGridViewColumn^  >(1) {this->Column2});
			this->Grid2->Location = System::Drawing::Point(394, 133);
			this->Grid2->Name = L"Grid2";
			this->Grid2->Size = System::Drawing::Size(240, 150);
			this->Grid2->TabIndex = 7;
			// 
			// Column2
			// 
			this->Column2->HeaderText = L"Verifivar";
			this->Column2->Name = L"Column2";
			// 
			// btnVer
			// 
			this->btnVer->Location = System::Drawing::Point(296, 198);
			this->btnVer->Name = L"btnVer";
			this->btnVer->Size = System::Drawing::Size(75, 23);
			this->btnVer->TabIndex = 8;
			this->btnVer->Text = L"Verificar";
			this->btnVer->UseVisualStyleBackColor = true;
			this->btnVer->Click += gcnew System::EventHandler(this, &Form1::btnVer_Click);
			// 
			// Form1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(667, 314);
			this->Controls->Add(this->btnVer);
			this->Controls->Add(this->Grid2);
			this->Controls->Add(this->Grid1);
			this->Controls->Add(this->button2);
			this->Controls->Add(this->btnTam);
			this->Controls->Add(this->txtNum);
			this->Controls->Add(this->txtTam);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->label1);
			this->Name = L"Form1";
			this->Text = L"Form1";
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->Grid1))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->Grid2))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void btnTam_Click(System::Object^  sender, System::EventArgs^  e) {
				 int tam;
				 tam= System::Convert::ToInt32(txtTam->Text);
				 e1.Set_Tamano(tam);
				 Grid1->RowCount=tam;
			 }
private: System::Void button2_Click(System::Object^  sender, System::EventArgs^  e) {
			  int elem;
			 int val;
			 elem=System::Convert::ToInt32(txtNum->Text);
			 e1.Set_Vector(pos, elem);
			 val= e1.Get_Vector(pos);
			 Grid1->Rows[pos]->Cells[0]->Value= val;
				  pos++;
		 }
private: System::Void btnVer_Click(System::Object^  sender, System::EventArgs^  e) {
			 bool u;
			 string o;
			  int tam;
				 tam= System::Convert::ToInt32(txtTam->Text);
				 Grid2->RowCount=tam;
				 for(int i=0; i<tam; i++)
				 {
			        u= e1.Calcular(tam,i); 	 
			        if(u==true)
			        {o= "par";}
			         else
			         o= "impar";
		         Grid2->Rows[i]->Cells[0]->Value=( marshal_as<System::String^>(o));
		         }
		 }
};
}

