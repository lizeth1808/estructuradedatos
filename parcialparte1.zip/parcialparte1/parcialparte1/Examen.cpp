#include "StdAfx.h"
#include "Examen.h"


Examen::Examen(void)
{
}
int Examen::Get_Tamano()
{
	return Tamano;
}
void Examen::Set_Tamano(int tam)
{
	Tamano=tam;
}
int Examen::Get_Vector(int posicion)
{
	return vec[posicion];
}
void Examen::Set_Vector(int posicion, int elemento)
{
	vec[posicion]=elemento;
}
bool Examen::Calcular(int t,int x)
{
	for(int i=0;i<t;i++)
	{
		if(vec[x]%2==0)
		{return true;}
		else 
		{return false;}
	}
}
