#include "StdAfx.h"
#include "Cola.h"


Cola::Cola(void)
{
	frente=-1;
	final=-1;
}
int Cola::Get_frente()
{
	return frente;
}
	bool Cola::Vacia()
	{
		if(frente==final)
			return true;
		else
			return false;
	}
	bool Cola::Llena()
	{
		if(final==N-1)
			return true;
		else
			return false;
	}
	bool Cola::Insertar(int x)
	{
		if(Llena()==true)
			return false;
		else
		{
			V[++final]= x;
			return true;
		}
	}
	int Cola::Eliminar(int x)
	{
		
		{
			x= V[++frente];
			return x;
		}
	}
