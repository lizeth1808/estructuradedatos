#pragma once
#include "Cola.h"

namespace EliminarRepetidos {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace std;

	Cola C1;
	Cola C2;
	int pos=0;

	/// <summary>
	/// Summary for Form1
	/// </summary>
	public ref class Form1 : public System::Windows::Forms::Form
	{
	public:
		Form1(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::TextBox^  txtTam;
	protected: 
	private: System::Windows::Forms::Button^  btnTam;
	private: System::Windows::Forms::TextBox^  txtNum;
	private: System::Windows::Forms::Button^  btnNum;
	private: System::Windows::Forms::DataGridView^  Grid;
	private: System::Windows::Forms::Button^  brnEliminar;

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->txtTam = (gcnew System::Windows::Forms::TextBox());
			this->btnTam = (gcnew System::Windows::Forms::Button());
			this->txtNum = (gcnew System::Windows::Forms::TextBox());
			this->btnNum = (gcnew System::Windows::Forms::Button());
			this->Grid = (gcnew System::Windows::Forms::DataGridView());
			this->brnEliminar = (gcnew System::Windows::Forms::Button());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->Grid))->BeginInit();
			this->SuspendLayout();
			// 
			// txtTam
			// 
			this->txtTam->Location = System::Drawing::Point(62, 27);
			this->txtTam->Name = L"txtTam";
			this->txtTam->Size = System::Drawing::Size(100, 20);
			this->txtTam->TabIndex = 0;
			// 
			// btnTam
			// 
			this->btnTam->Location = System::Drawing::Point(231, 27);
			this->btnTam->Name = L"btnTam";
			this->btnTam->Size = System::Drawing::Size(75, 23);
			this->btnTam->TabIndex = 1;
			this->btnTam->Text = L"Tamano";
			this->btnTam->UseVisualStyleBackColor = true;
			this->btnTam->Click += gcnew System::EventHandler(this, &Form1::btnTam_Click);
			// 
			// txtNum
			// 
			this->txtNum->Location = System::Drawing::Point(62, 72);
			this->txtNum->Name = L"txtNum";
			this->txtNum->Size = System::Drawing::Size(100, 20);
			this->txtNum->TabIndex = 2;
			// 
			// btnNum
			// 
			this->btnNum->Location = System::Drawing::Point(231, 69);
			this->btnNum->Name = L"btnNum";
			this->btnNum->Size = System::Drawing::Size(75, 23);
			this->btnNum->TabIndex = 3;
			this->btnNum->Text = L"Encolar";
			this->btnNum->UseVisualStyleBackColor = true;
			this->btnNum->Click += gcnew System::EventHandler(this, &Form1::btnNum_Click);
			// 
			// Grid
			// 
			this->Grid->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->Grid->Location = System::Drawing::Point(62, 112);
			this->Grid->Name = L"Grid";
			this->Grid->Size = System::Drawing::Size(240, 150);
			this->Grid->TabIndex = 4;
			// 
			// brnEliminar
			// 
			this->brnEliminar->Location = System::Drawing::Point(372, 70);
			this->brnEliminar->Name = L"brnEliminar";
			this->brnEliminar->Size = System::Drawing::Size(75, 23);
			this->brnEliminar->TabIndex = 5;
			this->brnEliminar->Text = L"Eliminar";
			this->brnEliminar->UseVisualStyleBackColor = true;
			this->brnEliminar->Click += gcnew System::EventHandler(this, &Form1::brnEliminar_Click);
			// 
			// Form1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(648, 274);
			this->Controls->Add(this->brnEliminar);
			this->Controls->Add(this->Grid);
			this->Controls->Add(this->btnNum);
			this->Controls->Add(this->txtNum);
			this->Controls->Add(this->btnTam);
			this->Controls->Add(this->txtTam);
			this->Name = L"Form1";
			this->Text = L"Form1";
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->Grid))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void btnTam_Click(System::Object^  sender, System::EventArgs^  e) {
				 int tam;
				 tam= System::Convert::ToInt32(txtTam->Text);
				 Grid->RowCount= tam;
			 }
private: System::Void btnNum_Click(System::Object^  sender, System::EventArgs^  e) {
			 int elem;
			 elem= System::Convert::ToInt32(txtNum->Text);
			 C1.Insertar(elem);
			 Grid->Rows[pos]->Cells[0]->Value= elem;
			 pos++;
		 }
private: System::Void brnEliminar_Click(System::Object^  sender, System::EventArgs^  e) {
			 int y;
			 while(C1.Vacia()==false)
			 {
				 y= C1.Eliminar();
				 if( y!=C1.Get_frente())
				 {
					 C2.Insertar(elem);

		 }
};
}

