#pragma once
#define N 9
class Cola
{
private:
	int frente;
	int final;
	int V[N];
public:
	Cola(void);
	int Get_frente();
	bool Vacia();
	bool Llena();
	bool Insertar(int x);
	int Eliminar(int x);
	
};

