#pragma once
#include <iostream>
#include "Cola.h"
#include <msclr\marshal_cppstd.h>
#include "string"

using namespace msclr::interop;
using namespace std;
using namespace System::Windows::Forms;
 class Operaciones:public Cola
{
public:
	Operaciones(void);
	void Guardar_Cola(DataGridView^ Grilla);
	void Mostrar_Cola(DataGridView^ Grilla);
	int Longitud();

};

