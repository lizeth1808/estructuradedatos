#include "StdAfx.h"
#include "NODO.h"


NODO::NODO(void)
{
	numero=0;
	nombre="";
}
string NODO::Get_nombre()
{
	return nombre;
}
void NODO::Set_nombre(string nom)
{
	nombre=nom;
}
int NODO::Get_numero()
{
	return numero;
}
void NODO::Set_numero(int num)
{
	numero=num;
}