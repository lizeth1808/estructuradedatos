#pragma once
#include <iostream>
#include "string"
#include <msclr\marshal_cppstd.h>

using namespace std;

class NODO
{
private:
	string nombre;
	int numero;
public:
	NODO(void);
	string Get_nombre();
	void Set_nombre(string nom);
	int Get_numero();
	void Set_numero(int num);
};

