#include "StdAfx.h"
#include "Cola.h"


Cola::Cola(void)
{
	frente=-1;
	final=-1;
}
bool Cola::Vacia()
{
	if(frente==final)
		return true;
	else
		return false;
}
bool Cola::Llena()
{
	if(final==N-1)
		return true;
	else
		return false;
}
bool Cola::Insertar(NODO x)
{
	if(Llena()==true)
		return false;
	else
	    {V[++final]=x;
	return true;
	}
}
bool  Cola::Eliminar(NODO &x)
{
	if(Vacia()==true)
		return false;
	else
	{x=V[++frente];
		return true;
	}
}
int Cola::Get_frente()
{
	return frente;
}
Cola Cola::This_Cola()
{
	return *this;
}
void Cola::This_Cola(Cola x)
{
	*this=x;
}
