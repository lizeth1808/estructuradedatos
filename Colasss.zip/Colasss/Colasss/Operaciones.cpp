#include "StdAfx.h"
#include "Operaciones.h"


Operaciones::Operaciones(void)
{
	Cola();
}
void Operaciones::Guardar_Cola(DataGridView^ Grilla)
{
	NODO x;
	int i=0;
	while(i<Grilla->ColumnCount)
	{
		x.Set_numero(System::Convert::ToInt32(Grilla->Rows[0]->Cells[i]->Value));
		x.Set_nombre(marshal_as<std::string>(System::Convert::ToString(Grilla->Rows[1]->Cells[i]->Value)));
		Cola::Insertar(x);
		i++;
	}
}
void Operaciones::Mostrar_Cola(DataGridView^ Grilla)
{
	Cola aux;
	aux= This_Cola();
	NODO elem;
	Grilla->ColumnCount= Longitud();
	Grilla->RowCount=2;
	int i=0;
	while(aux.Vacia()==false)
	{
		aux.Eliminar(elem);
		Grilla->Rows[0]->Cells[i]->Value=System::Convert::ToString(elem.Get_numero());
		Grilla->Rows[1]->Cells[i]->Value=marshal_as<System::String^>((elem.Get_nombre()));
		i++;
	}
}
int Operaciones::Longitud()
{
	int c=0;
	Cola aux;
	aux= This_Cola();
	NODO x;
	while(aux.Vacia()==false)
	{
		aux.Eliminar(x);
		c++;
	}
	return c;
}
