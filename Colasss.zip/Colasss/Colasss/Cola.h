#pragma once
#include <iostream>
#include "NODO.h"
#include "string"
#include <msclr\marshal_cppstd.h>
#define N 9
using namespace std;
class Cola
{
private:
	int frente;
	int final;
	NODO V[N];
public:
	Cola(void);
	bool Vacia();
	bool Llena();
	bool Insertar(NODO x);
	bool Eliminar(NODO &x);
	int Get_frente();

	Cola This_Cola();
	void This_Cola(Cola x);
};

