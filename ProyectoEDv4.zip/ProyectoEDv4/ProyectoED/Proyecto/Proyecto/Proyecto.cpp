// Proyecto.cpp : main project file.

#include "stdafx.h"
#include "FrmMenuPrincipal.h"

using namespace Proyecto;

[STAThreadAttribute]
int main(array<System::String ^> ^args)
{
	// Enabling Windows XP visual effects before any controls are created
	Application::EnableVisualStyles();
	Application::SetCompatibleTextRenderingDefault(false); 

	// Create the main window and run it
	Application::Run(gcnew frmMenuPrincipal());
	return 0;
}
