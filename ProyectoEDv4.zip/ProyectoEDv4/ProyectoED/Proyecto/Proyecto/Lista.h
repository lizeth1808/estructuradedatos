#pragma once
#define K 50
#include "Nodo.h"
class Lista:public Nodo
{
	int tope;
	Nodo V[K];
public: 
	Lista(void);
	bool vacio();
	bool lleno();
	bool eliminar(Nodo &x);
	void Insertar(Nodo pe);
};

