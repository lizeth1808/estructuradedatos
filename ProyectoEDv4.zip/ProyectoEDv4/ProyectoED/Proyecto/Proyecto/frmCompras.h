#pragma once
#include "Persona.h"
#include "Nodo.h"
#include "Lista.h"
#include "RegistroProducto.h"
#include "RegistroCliente.h"
#include <iostream>
#include <string>
#include <time.h>
#include <msclr\marshal_cppstd.h>
namespace Proyecto {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace std;
	using namespace msclr::interop;

	

	/// <summary>
	/// Summary for Form1
	/// </summary>
    static struct struct_producto registro_producto;
	static struct struct_cliente registro_cliente2;
	static FILE *archivo_producto;
	static FILE *archivo_cliente2;
	public ref class frmCompras : public System::Windows::Forms::Form

	{
	public:
		frmCompras(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
			
			B=new Persona();
			A=new Nodo();
			C=new Lista();

		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~frmCompras()
		{
			if (components)
			{
				delete components;
			}
		}


	
	static FILE *alias;
	private: System::Windows::Forms::Button^  btnProducto;
	private: System::Windows::Forms::TextBox^  txtSaldoCliente;
	private: System::Windows::Forms::TextBox^  txtNombreProductoSeleccionado;

	protected: 

	protected: 

	protected: 

	private: System::Windows::Forms::Label^  label1;
	private: System::Windows::Forms::Label^  label2;
	private: System::Windows::Forms::Label^  label3;
	private: System::Windows::Forms::TextBox^  txtSaldoClienteNuevo;
	private: System::Windows::Forms::DataGridView^  GridLista;
	private: System::Windows::Forms::DataGridView^  GridProducto;
	private: System::Windows::Forms::Button^  button2;
	private: System::Windows::Forms::Button^  btnEliminar;


	private: System::Windows::Forms::Label^  label4;
	private: System::Windows::Forms::Button^  button1;
	private: System::Windows::Forms::Button^  button3;




	private: System::Windows::Forms::Label^  label5;
	private: System::ComponentModel::IContainer^  components;

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>


	Persona *B;
	Nodo *A;
	Lista *C;
	static int pos=0;
	private: System::Windows::Forms::GroupBox^  groupBox1;
	private: System::Windows::Forms::GroupBox^  groupBox2;
	private: System::Windows::Forms::TextBox^  txtNombreCliente;
	private: System::Windows::Forms::Label^  label7;
	private: System::Windows::Forms::Button^  btnBuscarCliente;
	private: System::Windows::Forms::ImageList^  imageList1;
	private: System::Windows::Forms::TextBox^  txtCICliente;
	private: System::Windows::Forms::Label^  label6;
	private: System::Windows::Forms::GroupBox^  groupBox3;


















private: System::Windows::Forms::GroupBox^  groupBox4;





private: System::Windows::Forms::TextBox^  txtCantidadProducto;
private: System::Windows::Forms::Label^  label8;






private: System::Windows::Forms::TextBox^  txtTotalCarrito;

private: System::Windows::Forms::Label^  label9;
private: System::Windows::Forms::Button^  btnConfirmarPedido;
private: System::Windows::Forms::DataGridViewTextBoxColumn^  Column1;
private: System::Windows::Forms::DataGridViewTextBoxColumn^  Column2;
private: System::Windows::Forms::DataGridViewTextBoxColumn^  column3;
private: System::Windows::Forms::DataGridViewTextBoxColumn^  Column4;
private: System::Windows::Forms::DataGridViewTextBoxColumn^  Grid;
private: System::Windows::Forms::DataGridViewTextBoxColumn^  Descripcion;
private: System::Windows::Forms::DataGridViewTextBoxColumn^  Precio;
private: System::Windows::Forms::DataGridViewTextBoxColumn^  Cantidad;
private: System::Windows::Forms::DataGridViewTextBoxColumn^  Subtotal;













		 static int tam=1;


#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->components = (gcnew System::ComponentModel::Container());
			System::ComponentModel::ComponentResourceManager^  resources = (gcnew System::ComponentModel::ComponentResourceManager(frmCompras::typeid));
			this->btnProducto = (gcnew System::Windows::Forms::Button());
			this->imageList1 = (gcnew System::Windows::Forms::ImageList(this->components));
			this->txtSaldoCliente = (gcnew System::Windows::Forms::TextBox());
			this->txtNombreProductoSeleccionado = (gcnew System::Windows::Forms::TextBox());
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->txtSaldoClienteNuevo = (gcnew System::Windows::Forms::TextBox());
			this->GridLista = (gcnew System::Windows::Forms::DataGridView());
			this->Grid = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->Descripcion = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->Precio = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->Cantidad = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->Subtotal = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->GridProducto = (gcnew System::Windows::Forms::DataGridView());
			this->Column1 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->Column2 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->column3 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->Column4 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->button2 = (gcnew System::Windows::Forms::Button());
			this->btnEliminar = (gcnew System::Windows::Forms::Button());
			this->label4 = (gcnew System::Windows::Forms::Label());
			this->button1 = (gcnew System::Windows::Forms::Button());
			this->button3 = (gcnew System::Windows::Forms::Button());
			this->label5 = (gcnew System::Windows::Forms::Label());
			this->groupBox1 = (gcnew System::Windows::Forms::GroupBox());
			this->txtCantidadProducto = (gcnew System::Windows::Forms::TextBox());
			this->label8 = (gcnew System::Windows::Forms::Label());
			this->groupBox2 = (gcnew System::Windows::Forms::GroupBox());
			this->txtNombreCliente = (gcnew System::Windows::Forms::TextBox());
			this->label7 = (gcnew System::Windows::Forms::Label());
			this->btnBuscarCliente = (gcnew System::Windows::Forms::Button());
			this->txtCICliente = (gcnew System::Windows::Forms::TextBox());
			this->label6 = (gcnew System::Windows::Forms::Label());
			this->groupBox3 = (gcnew System::Windows::Forms::GroupBox());
			this->groupBox4 = (gcnew System::Windows::Forms::GroupBox());
			this->btnConfirmarPedido = (gcnew System::Windows::Forms::Button());
			this->txtTotalCarrito = (gcnew System::Windows::Forms::TextBox());
			this->label9 = (gcnew System::Windows::Forms::Label());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->GridLista))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->GridProducto))->BeginInit();
			this->groupBox1->SuspendLayout();
			this->groupBox2->SuspendLayout();
			this->groupBox3->SuspendLayout();
			this->groupBox4->SuspendLayout();
			this->SuspendLayout();
			// 
			// btnProducto
			// 
			this->btnProducto->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(255)), static_cast<System::Int32>(static_cast<System::Byte>(224)), 
				static_cast<System::Int32>(static_cast<System::Byte>(192)));
			this->btnProducto->BackgroundImage = (cli::safe_cast<System::Drawing::Image^  >(resources->GetObject(L"btnProducto.BackgroundImage")));
			this->btnProducto->ImageList = this->imageList1;
			this->btnProducto->Location = System::Drawing::Point(201, 43);
			this->btnProducto->Margin = System::Windows::Forms::Padding(2);
			this->btnProducto->Name = L"btnProducto";
			this->btnProducto->Size = System::Drawing::Size(73, 32);
			this->btnProducto->TabIndex = 1;
			this->btnProducto->Text = L"Ingresar";
			this->btnProducto->UseVisualStyleBackColor = false;
			this->btnProducto->Click += gcnew System::EventHandler(this, &frmCompras::button1_Click);
			// 
			// imageList1
			// 
			this->imageList1->ImageStream = (cli::safe_cast<System::Windows::Forms::ImageListStreamer^  >(resources->GetObject(L"imageList1.ImageStream")));
			this->imageList1->TransparentColor = System::Drawing::Color::Transparent;
			this->imageList1->Images->SetKeyName(0, L"customer1.png");
			this->imageList1->Images->SetKeyName(1, L"dele1.png");
			this->imageList1->Images->SetKeyName(2, L"DELETE.ICO");
			this->imageList1->Images->SetKeyName(3, L"Diskette.ico");
			this->imageList1->Images->SetKeyName(4, L"DOCUMNT3.ICO");
			this->imageList1->Images->SetKeyName(5, L"listado1.png");
			this->imageList1->Images->SetKeyName(6, L"productos1.png");
			this->imageList1->Images->SetKeyName(7, L"salir.gif");
			this->imageList1->Images->SetKeyName(8, L"search.png");
			this->imageList1->Images->SetKeyName(9, L"venta1.png");
			// 
			// txtSaldoCliente
			// 
			this->txtSaldoCliente->Location = System::Drawing::Point(84, 74);
			this->txtSaldoCliente->Margin = System::Windows::Forms::Padding(2);
			this->txtSaldoCliente->Name = L"txtSaldoCliente";
			this->txtSaldoCliente->ReadOnly = true;
			this->txtSaldoCliente->Size = System::Drawing::Size(76, 20);
			this->txtSaldoCliente->TabIndex = 2;
			// 
			// txtNombreProductoSeleccionado
			// 
			this->txtNombreProductoSeleccionado->CharacterCasing = System::Windows::Forms::CharacterCasing::Upper;
			this->txtNombreProductoSeleccionado->Location = System::Drawing::Point(12, 50);
			this->txtNombreProductoSeleccionado->Margin = System::Windows::Forms::Padding(2);
			this->txtNombreProductoSeleccionado->Name = L"txtNombreProductoSeleccionado";
			this->txtNombreProductoSeleccionado->Size = System::Drawing::Size(166, 20);
			this->txtNombreProductoSeleccionado->TabIndex = 3;
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Font = (gcnew System::Drawing::Font(L"Arial Rounded MT Bold", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->label1->Location = System::Drawing::Point(27, 76);
			this->label1->Margin = System::Windows::Forms::Padding(2, 0, 2, 0);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(53, 18);
			this->label1->TabIndex = 4;
			this->label1->Text = L"Saldo";
			this->label1->Click += gcnew System::EventHandler(this, &frmCompras::label1_Click);
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Font = (gcnew System::Drawing::Font(L"Arial Rounded MT Bold", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->label2->Location = System::Drawing::Point(9, 23);
			this->label2->Margin = System::Windows::Forms::Padding(2, 0, 2, 0);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(82, 18);
			this->label2->TabIndex = 5;
			this->label2->Text = L"Producto";
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->BackColor = System::Drawing::Color::Snow;
			this->label3->BorderStyle = System::Windows::Forms::BorderStyle::Fixed3D;
			this->label3->Font = (gcnew System::Drawing::Font(L"Arial Rounded MT Bold", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->label3->Location = System::Drawing::Point(8, 253);
			this->label3->Margin = System::Windows::Forms::Padding(2, 0, 2, 0);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(157, 20);
			this->label3->TabIndex = 6;
			this->label3->Text = L"su nuevo saldo es:";
			// 
			// txtSaldoClienteNuevo
			// 
			this->txtSaldoClienteNuevo->Location = System::Drawing::Point(48, 276);
			this->txtSaldoClienteNuevo->Margin = System::Windows::Forms::Padding(2);
			this->txtSaldoClienteNuevo->Name = L"txtSaldoClienteNuevo";
			this->txtSaldoClienteNuevo->ReadOnly = true;
			this->txtSaldoClienteNuevo->Size = System::Drawing::Size(94, 20);
			this->txtSaldoClienteNuevo->TabIndex = 7;
			// 
			// GridLista
			// 
			this->GridLista->AllowUserToAddRows = false;
			this->GridLista->AllowUserToDeleteRows = false;
			this->GridLista->BackgroundColor = System::Drawing::Color::SandyBrown;
			this->GridLista->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->GridLista->Columns->AddRange(gcnew cli::array< System::Windows::Forms::DataGridViewColumn^  >(5) {this->Grid, this->Descripcion, 
				this->Precio, this->Cantidad, this->Subtotal});
			this->GridLista->Location = System::Drawing::Point(8, 18);
			this->GridLista->Margin = System::Windows::Forms::Padding(2);
			this->GridLista->Name = L"GridLista";
			this->GridLista->ReadOnly = true;
			this->GridLista->RowTemplate->Height = 24;
			this->GridLista->Size = System::Drawing::Size(456, 191);
			this->GridLista->TabIndex = 8;
			// 
			// Grid
			// 
			this->Grid->HeaderText = L"Nro.";
			this->Grid->Name = L"Grid";
			this->Grid->ReadOnly = true;
			this->Grid->Width = 50;
			// 
			// Descripcion
			// 
			this->Descripcion->HeaderText = L"Descripcion";
			this->Descripcion->Name = L"Descripcion";
			this->Descripcion->ReadOnly = true;
			this->Descripcion->Width = 150;
			// 
			// Precio
			// 
			this->Precio->HeaderText = L"Precio";
			this->Precio->Name = L"Precio";
			this->Precio->ReadOnly = true;
			this->Precio->Width = 70;
			// 
			// Cantidad
			// 
			this->Cantidad->HeaderText = L"Cantidad";
			this->Cantidad->Name = L"Cantidad";
			this->Cantidad->ReadOnly = true;
			this->Cantidad->Width = 70;
			// 
			// Subtotal
			// 
			this->Subtotal->HeaderText = L"Subtotal";
			this->Subtotal->Name = L"Subtotal";
			this->Subtotal->ReadOnly = true;
			this->Subtotal->Width = 70;
			// 
			// GridProducto
			// 
			this->GridProducto->AllowUserToAddRows = false;
			this->GridProducto->BackgroundColor = System::Drawing::Color::LightCoral;
			this->GridProducto->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->GridProducto->Columns->AddRange(gcnew cli::array< System::Windows::Forms::DataGridViewColumn^  >(4) {this->Column1, 
				this->Column2, this->column3, this->Column4});
			this->GridProducto->Location = System::Drawing::Point(8, 18);
			this->GridProducto->Margin = System::Windows::Forms::Padding(2);
			this->GridProducto->Name = L"GridProducto";
			this->GridProducto->RowTemplate->Height = 24;
			this->GridProducto->Size = System::Drawing::Size(544, 85);
			this->GridProducto->TabIndex = 9;
			this->GridProducto->CellContentClick += gcnew System::Windows::Forms::DataGridViewCellEventHandler(this, &frmCompras::dataGridView2_CellContentClick);
			// 
			// Column1
			// 
			this->Column1->HeaderText = L"Producto";
			this->Column1->Name = L"Column1";
			// 
			// Column2
			// 
			this->Column2->HeaderText = L"Supermercado 1";
			this->Column2->Name = L"Column2";
			// 
			// column3
			// 
			this->column3->HeaderText = L"Supermercado 2";
			this->column3->Name = L"column3";
			// 
			// Column4
			// 
			this->Column4->HeaderText = L"Supermercado 3";
			this->Column4->Name = L"Column4";
			// 
			// button2
			// 
			this->button2->BackColor = System::Drawing::Color::Snow;
			this->button2->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 10.8F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->button2->Location = System::Drawing::Point(285, 125);
			this->button2->Margin = System::Windows::Forms::Padding(2);
			this->button2->Name = L"button2";
			this->button2->Size = System::Drawing::Size(28, 31);
			this->button2->TabIndex = 11;
			this->button2->Text = L"1";
			this->button2->UseVisualStyleBackColor = false;
			this->button2->Click += gcnew System::EventHandler(this, &frmCompras::button2_Click);
			// 
			// btnEliminar
			// 
			this->btnEliminar->BackColor = System::Drawing::Color::Snow;
			this->btnEliminar->Location = System::Drawing::Point(468, 60);
			this->btnEliminar->Margin = System::Windows::Forms::Padding(2);
			this->btnEliminar->Name = L"btnEliminar";
			this->btnEliminar->Size = System::Drawing::Size(73, 19);
			this->btnEliminar->TabIndex = 12;
			this->btnEliminar->Text = L"Eliminar";
			this->btnEliminar->UseVisualStyleBackColor = false;
			this->btnEliminar->Click += gcnew System::EventHandler(this, &frmCompras::btnEliminar_Click);
			// 
			// label4
			// 
			this->label4->AutoSize = true;
			this->label4->Location = System::Drawing::Point(18, 108);
			this->label4->Margin = System::Windows::Forms::Padding(2, 0, 2, 0);
			this->label4->Name = L"label4";
			this->label4->Size = System::Drawing::Size(160, 39);
			this->label4->TabIndex = 13;
			this->label4->Text = L"Porfavor seleccione una opcion:\r\n\r\n\r\n";
			// 
			// button1
			// 
			this->button1->BackColor = System::Drawing::Color::Snow;
			this->button1->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 10.8F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->button1->Location = System::Drawing::Point(360, 125);
			this->button1->Margin = System::Windows::Forms::Padding(2);
			this->button1->Name = L"button1";
			this->button1->Size = System::Drawing::Size(28, 31);
			this->button1->TabIndex = 14;
			this->button1->Text = L"2";
			this->button1->UseVisualStyleBackColor = false;
			this->button1->Click += gcnew System::EventHandler(this, &frmCompras::button1_Click_1);
			// 
			// button3
			// 
			this->button3->BackColor = System::Drawing::Color::Snow;
			this->button3->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 10.8F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->button3->Location = System::Drawing::Point(436, 125);
			this->button3->Margin = System::Windows::Forms::Padding(2);
			this->button3->Name = L"button3";
			this->button3->Size = System::Drawing::Size(28, 31);
			this->button3->TabIndex = 15;
			this->button3->Text = L"3";
			this->button3->UseVisualStyleBackColor = false;
			this->button3->Click += gcnew System::EventHandler(this, &frmCompras::button3_Click);
			// 
			// label5
			// 
			this->label5->AutoSize = true;
			this->label5->Font = (gcnew System::Drawing::Font(L"Rage Italic", 36, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->label5->ForeColor = System::Drawing::Color::Black;
			this->label5->Image = (cli::safe_cast<System::Drawing::Image^  >(resources->GetObject(L"label5.Image")));
			this->label5->Location = System::Drawing::Point(11, 245);
			this->label5->Margin = System::Windows::Forms::Padding(2, 0, 2, 0);
			this->label5->Name = L"label5";
			this->label5->Size = System::Drawing::Size(236, 61);
			this->label5->TabIndex = 18;
			this->label5->Text = L"TU LISTA";
			// 
			// groupBox1
			// 
			this->groupBox1->Controls->Add(this->txtCantidadProducto);
			this->groupBox1->Controls->Add(this->label8);
			this->groupBox1->Controls->Add(this->GridProducto);
			this->groupBox1->Controls->Add(this->button3);
			this->groupBox1->Controls->Add(this->button2);
			this->groupBox1->Controls->Add(this->label4);
			this->groupBox1->Controls->Add(this->button1);
			this->groupBox1->Location = System::Drawing::Point(339, 6);
			this->groupBox1->Name = L"groupBox1";
			this->groupBox1->Size = System::Drawing::Size(557, 173);
			this->groupBox1->TabIndex = 19;
			this->groupBox1->TabStop = false;
			this->groupBox1->Text = L"Comparaci�n de precios";
			// 
			// txtCantidadProducto
			// 
			this->txtCantidadProducto->Location = System::Drawing::Point(175, 132);
			this->txtCantidadProducto->Margin = System::Windows::Forms::Padding(2);
			this->txtCantidadProducto->Name = L"txtCantidadProducto";
			this->txtCantidadProducto->Size = System::Drawing::Size(76, 20);
			this->txtCantidadProducto->TabIndex = 16;
			this->txtCantidadProducto->TextAlign = System::Windows::Forms::HorizontalAlignment::Center;
			// 
			// label8
			// 
			this->label8->AutoSize = true;
			this->label8->Font = (gcnew System::Drawing::Font(L"Arial Rounded MT Bold", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->label8->Location = System::Drawing::Point(5, 132);
			this->label8->Margin = System::Windows::Forms::Padding(2, 0, 2, 0);
			this->label8->Name = L"label8";
			this->label8->Size = System::Drawing::Size(166, 18);
			this->label8->TabIndex = 17;
			this->label8->Text = L"Cantidad a comprar";
			// 
			// groupBox2
			// 
			this->groupBox2->Controls->Add(this->txtNombreCliente);
			this->groupBox2->Controls->Add(this->label7);
			this->groupBox2->Controls->Add(this->btnBuscarCliente);
			this->groupBox2->Controls->Add(this->txtCICliente);
			this->groupBox2->Controls->Add(this->label6);
			this->groupBox2->Controls->Add(this->txtSaldoCliente);
			this->groupBox2->Controls->Add(this->label1);
			this->groupBox2->Location = System::Drawing::Point(9, 6);
			this->groupBox2->Name = L"groupBox2";
			this->groupBox2->Size = System::Drawing::Size(287, 109);
			this->groupBox2->TabIndex = 20;
			this->groupBox2->TabStop = false;
			this->groupBox2->Text = L"Datos del cliente";
			// 
			// txtNombreCliente
			// 
			this->txtNombreCliente->Location = System::Drawing::Point(84, 50);
			this->txtNombreCliente->Margin = System::Windows::Forms::Padding(2);
			this->txtNombreCliente->Name = L"txtNombreCliente";
			this->txtNombreCliente->ReadOnly = true;
			this->txtNombreCliente->Size = System::Drawing::Size(190, 20);
			this->txtNombreCliente->TabIndex = 8;
			// 
			// label7
			// 
			this->label7->AutoSize = true;
			this->label7->Font = (gcnew System::Drawing::Font(L"Arial Rounded MT Bold", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->label7->Location = System::Drawing::Point(9, 50);
			this->label7->Margin = System::Windows::Forms::Padding(2, 0, 2, 0);
			this->label7->Name = L"label7";
			this->label7->Size = System::Drawing::Size(71, 18);
			this->label7->TabIndex = 9;
			this->label7->Text = L"Nombre";
			// 
			// btnBuscarCliente
			// 
			this->btnBuscarCliente->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->btnBuscarCliente->ImageAlign = System::Drawing::ContentAlignment::MiddleRight;
			this->btnBuscarCliente->ImageIndex = 8;
			this->btnBuscarCliente->ImageList = this->imageList1;
			this->btnBuscarCliente->Location = System::Drawing::Point(165, 12);
			this->btnBuscarCliente->Name = L"btnBuscarCliente";
			this->btnBuscarCliente->Size = System::Drawing::Size(112, 34);
			this->btnBuscarCliente->TabIndex = 7;
			this->btnBuscarCliente->Text = L"Buscar";
			this->btnBuscarCliente->UseVisualStyleBackColor = true;
			this->btnBuscarCliente->Click += gcnew System::EventHandler(this, &frmCompras::btnBuscarCliente_Click);
			// 
			// txtCICliente
			// 
			this->txtCICliente->Location = System::Drawing::Point(84, 26);
			this->txtCICliente->Margin = System::Windows::Forms::Padding(2);
			this->txtCICliente->Name = L"txtCICliente";
			this->txtCICliente->Size = System::Drawing::Size(76, 20);
			this->txtCICliente->TabIndex = 5;
			// 
			// label6
			// 
			this->label6->AutoSize = true;
			this->label6->Font = (gcnew System::Drawing::Font(L"Arial Rounded MT Bold", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->label6->Location = System::Drawing::Point(45, 26);
			this->label6->Margin = System::Windows::Forms::Padding(2, 0, 2, 0);
			this->label6->Name = L"label6";
			this->label6->Size = System::Drawing::Size(35, 18);
			this->label6->TabIndex = 6;
			this->label6->Text = L"C.I.";
			// 
			// groupBox3
			// 
			this->groupBox3->Controls->Add(this->label2);
			this->groupBox3->Controls->Add(this->txtNombreProductoSeleccionado);
			this->groupBox3->Controls->Add(this->btnProducto);
			this->groupBox3->Location = System::Drawing::Point(9, 121);
			this->groupBox3->Name = L"groupBox3";
			this->groupBox3->Size = System::Drawing::Size(287, 104);
			this->groupBox3->TabIndex = 21;
			this->groupBox3->TabStop = false;
			this->groupBox3->Text = L"Productos";
			// 
			// groupBox4
			// 
			this->groupBox4->Controls->Add(this->btnConfirmarPedido);
			this->groupBox4->Controls->Add(this->txtTotalCarrito);
			this->groupBox4->Controls->Add(this->label9);
			this->groupBox4->Controls->Add(this->GridLista);
			this->groupBox4->Controls->Add(this->label3);
			this->groupBox4->Controls->Add(this->txtSaldoClienteNuevo);
			this->groupBox4->Controls->Add(this->btnEliminar);
			this->groupBox4->Location = System::Drawing::Point(339, 185);
			this->groupBox4->Name = L"groupBox4";
			this->groupBox4->Size = System::Drawing::Size(557, 302);
			this->groupBox4->TabIndex = 22;
			this->groupBox4->TabStop = false;
			this->groupBox4->Text = L"Carrito de compras";
			// 
			// btnConfirmarPedido
			// 
			this->btnConfirmarPedido->BackColor = System::Drawing::Color::White;
			this->btnConfirmarPedido->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 10.2F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->btnConfirmarPedido->ForeColor = System::Drawing::Color::Black;
			this->btnConfirmarPedido->Location = System::Drawing::Point(300, 268);
			this->btnConfirmarPedido->Margin = System::Windows::Forms::Padding(2);
			this->btnConfirmarPedido->Name = L"btnConfirmarPedido";
			this->btnConfirmarPedido->Size = System::Drawing::Size(164, 28);
			this->btnConfirmarPedido->TabIndex = 20;
			this->btnConfirmarPedido->Text = L"confirmar pedido";
			this->btnConfirmarPedido->UseVisualStyleBackColor = false;
			this->btnConfirmarPedido->Click += gcnew System::EventHandler(this, &frmCompras::btnConfirmarPedido_Click);
			// 
			// txtTotalCarrito
			// 
			this->txtTotalCarrito->Location = System::Drawing::Point(374, 232);
			this->txtTotalCarrito->Margin = System::Windows::Forms::Padding(2);
			this->txtTotalCarrito->Name = L"txtTotalCarrito";
			this->txtTotalCarrito->ReadOnly = true;
			this->txtTotalCarrito->Size = System::Drawing::Size(90, 20);
			this->txtTotalCarrito->TabIndex = 19;
			this->txtTotalCarrito->Text = L"0";
			this->txtTotalCarrito->TextAlign = System::Windows::Forms::HorizontalAlignment::Center;
			// 
			// label9
			// 
			this->label9->AutoSize = true;
			this->label9->Font = (gcnew System::Drawing::Font(L"Arial Rounded MT Bold", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->label9->Location = System::Drawing::Point(211, 232);
			this->label9->Margin = System::Windows::Forms::Padding(2, 0, 2, 0);
			this->label9->Name = L"label9";
			this->label9->Size = System::Drawing::Size(148, 18);
			this->label9->TabIndex = 18;
			this->label9->Text = L"Total Compra(Bs)";
			// 
			// frmCompras
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->BackColor = System::Drawing::Color::LightSalmon;
			this->BackgroundImageLayout = System::Windows::Forms::ImageLayout::None;
			this->ClientSize = System::Drawing::Size(908, 609);
			this->Controls->Add(this->groupBox4);
			this->Controls->Add(this->groupBox3);
			this->Controls->Add(this->groupBox2);
			this->Controls->Add(this->groupBox1);
			this->Controls->Add(this->label5);
			this->ForeColor = System::Drawing::SystemColors::ActiveCaptionText;
			this->Margin = System::Windows::Forms::Padding(2);
			this->MaximizeBox = false;
			this->Name = L"frmCompras";
			this->StartPosition = System::Windows::Forms::FormStartPosition::CenterScreen;
			this->Text = L"COMPRA";
			this->Load += gcnew System::EventHandler(this, &frmCompras::Form1_Load);
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->GridLista))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->GridProducto))->EndInit();
			this->groupBox1->ResumeLayout(false);
			this->groupBox1->PerformLayout();
			this->groupBox2->ResumeLayout(false);
			this->groupBox2->PerformLayout();
			this->groupBox3->ResumeLayout(false);
			this->groupBox3->PerformLayout();
			this->groupBox4->ResumeLayout(false);
			this->groupBox4->PerformLayout();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
 private: System::Void Procesar_Agregar_Producto_Carrito(int columnasuper)
		  {
            
            if(txtCantidadProducto->Text!="")
		    {
				if(GridProducto->Rows->Count>0)
				{
					int cod;
					string des;
					float pre,can,subtotal;
					int fila;
					
					des= marshal_as<string>(Convert::ToString(GridProducto[0,0]->Value));
					pre= Convert::ToDouble(GridProducto[columnasuper,0]->Value);
					can= Convert::ToDouble(txtCantidadProducto->Text);
					subtotal=pre*can;			
					A->Agregar(cod,des,pre,can);
					C->Insertar(*A);

					GridLista->Rows->Add();
					fila=GridLista->Rows->Count;

					GridLista[0,fila-1]->Value=System::Convert::ToString(fila);
					GridLista[1,fila-1]->Value=GridProducto[0,0]->Value;
					GridLista[2,fila-1]->Value=System::Convert::ToString(pre);
					GridLista[3,fila-1]->Value=System::Convert::ToString(can);
					GridLista[4,fila-1]->Value=System::Convert::ToString(subtotal);

					GridProducto->Rows->Clear();
					txtCantidadProducto->Clear();
					Procesar_Calcular_Total_Carrito();

					pos++;		 
				}
				else
				{
				  MessageBox::Show( "El producto seleccionado no es v�lido" );
				}
			}
			else
			{
			   MessageBox::Show( "Escriba la cantidad del producto a comprar" );
			   txtCantidadProducto->Focus();
			}

		  }

    private: System::Void Procesar_Calcular_Total_Carrito()
			 {
			 
			  int fila;
			  double total=0;
			  double saldoactual,saldonuevo;
			  saldoactual=System::Convert::ToDouble(txtSaldoCliente->Text);//Saldo actual
			  for(fila=0;fila<GridLista->Rows->Count;fila++)
			  {
			    total=total + System::Convert::ToDouble(GridLista[4,fila]->Value);
			  }
			  txtTotalCarrito->Text=System::Convert::ToString(total);
			  saldonuevo=saldoactual-total;
			  if(saldonuevo<=0)
			  {
			    saldonuevo=0;
			  }
			  txtSaldoClienteNuevo->Text=System::Convert::ToString(saldonuevo);
			  if(total>saldoactual)
			  {
			    MessageBox::Show( "Compra no v�lida.El monto de la compra es mayor al saldo del cliente" );
				btnConfirmarPedido->Enabled=false;
			  }
			  else
			  {
			    btnConfirmarPedido->Enabled=true;
			  }

			 }

	private: System::Void label1_Click(System::Object^  sender, System::EventArgs^  e) {
			 }
private: System::Void dataGridView1_CellContentClick(System::Object^  sender, System::Windows::Forms::DataGridViewCellEventArgs^  e) {
		 }
private: System::Void Form1_Load(System::Object^  sender, System::EventArgs^  e) {
		 }
private: System::Void dataGridView2_CellContentClick(System::Object^  sender, System::Windows::Forms::DataGridViewCellEventArgs^  e) {
		 }
private: System::Void listBox1_SelectedIndexChanged(System::Object^  sender, System::EventArgs^  e) {
		 }
private: System::Void button1_Click(System::Object^  sender, System::EventArgs^  e) 
		 {
            if(txtNombreProductoSeleccionado->Text!="")
			{
				if(txtCICliente->Text!="")
				{
					GridProducto->Rows->Add();
					double p1,p2,p3;
					srand(time(0));
					p1= rand()%10 +1;
					srand(time(0));
					p2= rand()%10 +2;
					srand(time(0));
					p3= rand()%10 +3;
				

					GridProducto[0,0]->Value=txtNombreProductoSeleccionado->Text;//nombre
					GridProducto[1,0]->Value=System::Convert::ToString(p1);
					GridProducto[2,0]->Value=System::Convert::ToString(p2);
					GridProducto[3,0]->Value=System::Convert::ToString(p3);

					txtNombreProductoSeleccionado->Clear();
				}
				else
				{
					MessageBox::Show( "Seleccione el cliente" );
					txtCICliente->Focus();				
				}
			}
			else
			{
                MessageBox::Show( "Escriba el nombre del producto" );
				txtNombreProductoSeleccionado->Focus();
			}
	}


private: System::Void button2_Click(System::Object^  sender, System::EventArgs^  e) 
		 {
	
			 Procesar_Agregar_Producto_Carrito(1);

		 }


private: System::Void button1_Click_1(System::Object^  sender, System::EventArgs^  e) {

             Procesar_Agregar_Producto_Carrito(2);
		 }


private: System::Void button3_Click(System::Object^  sender, System::EventArgs^  e) 
		 {

         Procesar_Agregar_Producto_Carrito(3);
}

private: System::Void btnEliminar_Click(System::Object^  sender, System::EventArgs^  e) {

			int cantidadfilas=GridLista->Rows->Count;
            if(cantidadfilas>0)
			{				
				Nodo elem;
				C->eliminar(elem);
	 			GridLista->Rows->RemoveAt(cantidadfilas-1);
				Procesar_Calcular_Total_Carrito();
			}
			else
			{
               MessageBox::Show( "El carrito esta vacio" );
			}
		 }
private: System::Void button4_Click(System::Object^  sender, System::EventArgs^  e) 
		 {
			int s=0;
			int elem;
			int NS;
			for(int i=0;i<pos;i++)
			{elem=System::Convert::ToInt32(GridLista->Rows[i]->Cells[1]->Value);
			s=s+elem;
			}
			NS=System::Convert::ToInt32(txtSaldoCliente->Text)-s;
			//txtFinal->Text=Convert::ToString(NS);

		 }
private: System::Void button5_Click(System::Object^  sender, System::EventArgs^  e) 
		 {


		 }
private: System::Void btnListadoProductos_Click(System::Object^  sender, System::EventArgs^  e) {



		 }
private: System::Void btnBuscarCliente_Click(System::Object^  sender, System::EventArgs^  e) {


      if(txtCICliente->Text!="")
	  {
			 int cibuscado=Convert::ToInt32(txtCICliente->Text);				

 			 string nomb;
			 string gara;
			 int contador=0;

			 archivo_cliente2=fopen("SUPERCLIENTE.SEC","rb");
			 if(archivo_cliente2!=NULL)
			 {
			 
				fread(&registro_cliente2,sizeof(registro_cliente2),1,archivo_cliente2);
				// Lee el "Registro", de tamano=sizeof(Registro) del archivo "alias"
				bool swencontrado=false;
				while((!feof(archivo_cliente2))&&(swencontrado==false)) // Ciclo mientras no se encuentre el final del archivo				
				{
					contador++;
					nomb=registro_cliente2.nombre;

					if(registro_cliente2.ci==cibuscado)
					{
					  swencontrado=true;
					  txtNombreCliente->Text=gcnew String(nomb.c_str());
					  txtSaldoCliente->Text=Convert::ToString(registro_cliente2.saldo);
					}

					fread(&registro_cliente2,sizeof(registro_cliente2),1,archivo_cliente2);//lee el siguiente registro o bloque de archivo

				}
			    fclose(archivo_cliente2);
				if(swencontrado==false)
				{
					MessageBox::Show( "El cliente no existe" );
					txtCICliente->Clear();
					txtNombreCliente->Clear();
					txtSaldoCliente->Clear();
					txtCICliente->Focus();
				}
			 }
			 else
			 {
			    MessageBox::Show( "El archivo no existe" );
			 }
	  }
	  else
	  {
	  	    MessageBox::Show( "Escriba el CI del cliente" );
			txtCICliente->Focus();
	  }

 }
private: System::Void dgvProductos_CellContentClick(System::Object^  sender, System::Windows::Forms::DataGridViewCellEventArgs^  e) {
		 }
private: System::Void dgvProductos_RowEnter(System::Object^  sender, System::Windows::Forms::DataGridViewCellEventArgs^  e) {


		 }
private: System::Void btnConfirmarPedido_Click(System::Object^  sender, System::EventArgs^  e) 
		 {
			 GridLista->Rows->Clear();
			 txtSaldoCliente->Text=txtSaldoClienteNuevo->Text;
			 txtSaldoClienteNuevo->Clear();
			 txtTotalCarrito->Clear();
			 MessageBox::Show ("PEDIDO CONFIRMADO");
		 }
};
}

 