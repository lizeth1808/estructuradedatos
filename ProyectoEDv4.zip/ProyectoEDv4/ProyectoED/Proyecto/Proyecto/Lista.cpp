#include "StdAfx.h"
#include "Lista.h"


Lista::Lista(void)
{tope= -1;
}

bool Lista::vacio()
{if (tope==-1)
return true;

}

bool Lista::lleno()
{if (tope<=K)
return true;
}
bool Lista::eliminar(Nodo &x)
{Nodo pe=V[tope--];
return true;
}

void Lista::Insertar(Nodo pe)
{V[++tope]=pe;
}