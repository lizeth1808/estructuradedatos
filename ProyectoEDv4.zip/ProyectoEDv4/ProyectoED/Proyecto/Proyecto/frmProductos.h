#pragma once
#include <iostream>
#include <string>
#include <time.h>
#include <msclr\marshal_cppstd.h>
namespace Proyecto {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace msclr::interop;
	/// <summary>
	/// Summary for frmProductos
	/// </summary>
	struct tipo_registro
	{
		int no_prod;
		char descrip[50];
	    int cantidad;
		float precio1;
		float precio2;
		float precio3;
		
	};

	static struct tipo_registro Registro;
	
	static FILE *alias;
	public ref class frmProductos : public System::Windows::Forms::Form
	{
	public:
		frmProductos(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~frmProductos()
		{
			if (components)
			{
				delete components;
			}
		}

	protected: 


	private: System::Windows::Forms::Label^  label1;
	public: System::Windows::Forms::TextBox^  txtPrecio1;
	private: 

	private: 

	public: 


	public: System::Windows::Forms::TextBox^  txtDescripcion;
	private: 
	private: System::Windows::Forms::Label^  label5;
	public: 
	private: System::Windows::Forms::Label^  label4;
	public: System::Windows::Forms::TextBox^  txtCantidad;
	private: 
	public: System::Windows::Forms::TextBox^  txtNroProducto;
	private: System::Windows::Forms::Label^  label2;
	private: System::Windows::Forms::Label^  label3;
	private: System::Windows::Forms::GroupBox^  groupBox1;
	private: System::Windows::Forms::Button^  btnListadoProducto;

	private: System::Windows::Forms::ImageList^  imageList1;
	private: System::Windows::Forms::Button^  btnGuardarProducto;
	private: System::Windows::Forms::GroupBox^  groupBox2;
	private: System::Windows::Forms::DataGridView^  dgvProductos;





	private: System::Windows::Forms::Label^  label6;
	public: System::Windows::Forms::TextBox^  txtPrecio2;
	private: 

	private: 
	private: System::Windows::Forms::Label^  label7;
	public: System::Windows::Forms::TextBox^  txtPrecio3;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  Nro;
	public: 
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  CI;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  Nombre;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  Saldo;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  Precio1;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  Precio2;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  Precio3;
	private: 
	public: 

	private: 

	private: System::ComponentModel::IContainer^  components;
	public: 

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>


#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->components = (gcnew System::ComponentModel::Container());
			System::ComponentModel::ComponentResourceManager^  resources = (gcnew System::ComponentModel::ComponentResourceManager(frmProductos::typeid));
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->txtPrecio1 = (gcnew System::Windows::Forms::TextBox());
			this->txtDescripcion = (gcnew System::Windows::Forms::TextBox());
			this->label5 = (gcnew System::Windows::Forms::Label());
			this->label4 = (gcnew System::Windows::Forms::Label());
			this->txtCantidad = (gcnew System::Windows::Forms::TextBox());
			this->txtNroProducto = (gcnew System::Windows::Forms::TextBox());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->groupBox1 = (gcnew System::Windows::Forms::GroupBox());
			this->btnListadoProducto = (gcnew System::Windows::Forms::Button());
			this->imageList1 = (gcnew System::Windows::Forms::ImageList(this->components));
			this->btnGuardarProducto = (gcnew System::Windows::Forms::Button());
			this->groupBox2 = (gcnew System::Windows::Forms::GroupBox());
			this->dgvProductos = (gcnew System::Windows::Forms::DataGridView());
			this->Nro = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->CI = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->Nombre = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->Saldo = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->Precio1 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->Precio2 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->Precio3 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->label6 = (gcnew System::Windows::Forms::Label());
			this->txtPrecio2 = (gcnew System::Windows::Forms::TextBox());
			this->label7 = (gcnew System::Windows::Forms::Label());
			this->txtPrecio3 = (gcnew System::Windows::Forms::TextBox());
			this->groupBox1->SuspendLayout();
			this->groupBox2->SuspendLayout();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->dgvProductos))->BeginInit();
			this->SuspendLayout();
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 10.2F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->label1->Location = System::Drawing::Point(32, 186);
			this->label1->Margin = System::Windows::Forms::Padding(2, 0, 2, 0);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(156, 17);
			this->label1->TabIndex = 69;
			this->label1->Text = L"Precio 1 (Hipermaxi)";
			// 
			// txtPrecio1
			// 
			this->txtPrecio1->Location = System::Drawing::Point(192, 183);
			this->txtPrecio1->Margin = System::Windows::Forms::Padding(2);
			this->txtPrecio1->Name = L"txtPrecio1";
			this->txtPrecio1->Size = System::Drawing::Size(76, 20);
			this->txtPrecio1->TabIndex = 4;
			// 
			// txtDescripcion
			// 
			this->txtDescripcion->CharacterCasing = System::Windows::Forms::CharacterCasing::Upper;
			this->txtDescripcion->Location = System::Drawing::Point(192, 128);
			this->txtDescripcion->Margin = System::Windows::Forms::Padding(2);
			this->txtDescripcion->Name = L"txtDescripcion";
			this->txtDescripcion->Size = System::Drawing::Size(141, 20);
			this->txtDescripcion->TabIndex = 2;
			// 
			// label5
			// 
			this->label5->AutoSize = true;
			this->label5->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 10.2F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->label5->Location = System::Drawing::Point(91, 130);
			this->label5->Margin = System::Windows::Forms::Padding(2, 0, 2, 0);
			this->label5->Name = L"label5";
			this->label5->Size = System::Drawing::Size(93, 17);
			this->label5->TabIndex = 65;
			this->label5->Text = L"Descripcion";
			// 
			// label4
			// 
			this->label4->AutoSize = true;
			this->label4->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 10.2F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->label4->Location = System::Drawing::Point(112, 157);
			this->label4->Margin = System::Windows::Forms::Padding(2, 0, 2, 0);
			this->label4->Name = L"label4";
			this->label4->Size = System::Drawing::Size(72, 17);
			this->label4->TabIndex = 64;
			this->label4->Text = L"Cantidad";
			// 
			// txtCantidad
			// 
			this->txtCantidad->Location = System::Drawing::Point(192, 154);
			this->txtCantidad->Margin = System::Windows::Forms::Padding(2);
			this->txtCantidad->Name = L"txtCantidad";
			this->txtCantidad->Size = System::Drawing::Size(76, 20);
			this->txtCantidad->TabIndex = 3;
			// 
			// txtNroProducto
			// 
			this->txtNroProducto->Location = System::Drawing::Point(192, 104);
			this->txtNroProducto->Margin = System::Windows::Forms::Padding(2);
			this->txtNroProducto->Name = L"txtNroProducto";
			this->txtNroProducto->Size = System::Drawing::Size(76, 20);
			this->txtNroProducto->TabIndex = 1;
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 10.2F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->label2->Location = System::Drawing::Point(80, 104);
			this->label2->Margin = System::Windows::Forms::Padding(2, 0, 2, 0);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(108, 17);
			this->label2->TabIndex = 63;
			this->label2->Text = L"Nro. producto";
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->BackColor = System::Drawing::Color::Red;
			this->label3->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 48, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->label3->ForeColor = System::Drawing::Color::LavenderBlush;
			this->label3->Image = (cli::safe_cast<System::Drawing::Image^  >(resources->GetObject(L"label3.Image")));
			this->label3->Location = System::Drawing::Point(76, 9);
			this->label3->Margin = System::Windows::Forms::Padding(2, 0, 2, 0);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(399, 73);
			this->label3->TabIndex = 73;
			this->label3->Text = L"�Bienvenido!";
			// 
			// groupBox1
			// 
			this->groupBox1->Controls->Add(this->btnListadoProducto);
			this->groupBox1->Controls->Add(this->btnGuardarProducto);
			this->groupBox1->Location = System::Drawing::Point(428, 85);
			this->groupBox1->Name = L"groupBox1";
			this->groupBox1->Size = System::Drawing::Size(134, 114);
			this->groupBox1->TabIndex = 74;
			this->groupBox1->TabStop = false;
			// 
			// btnListadoProducto
			// 
			this->btnListadoProducto->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->btnListadoProducto->ImageAlign = System::Drawing::ContentAlignment::MiddleRight;
			this->btnListadoProducto->ImageIndex = 1;
			this->btnListadoProducto->ImageList = this->imageList1;
			this->btnListadoProducto->Location = System::Drawing::Point(6, 65);
			this->btnListadoProducto->Name = L"btnListadoProducto";
			this->btnListadoProducto->Size = System::Drawing::Size(119, 42);
			this->btnListadoProducto->TabIndex = 1;
			this->btnListadoProducto->Text = L"Listado";
			this->btnListadoProducto->UseVisualStyleBackColor = true;
			this->btnListadoProducto->Click += gcnew System::EventHandler(this, &frmProductos::btnListadoProducto_Click);
			// 
			// imageList1
			// 
			this->imageList1->ImageStream = (cli::safe_cast<System::Windows::Forms::ImageListStreamer^  >(resources->GetObject(L"imageList1.ImageStream")));
			this->imageList1->TransparentColor = System::Drawing::Color::Transparent;
			this->imageList1->Images->SetKeyName(0, L"Diskette.ico");
			this->imageList1->Images->SetKeyName(1, L"listado1.png");
			// 
			// btnGuardarProducto
			// 
			this->btnGuardarProducto->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->btnGuardarProducto->ImageAlign = System::Drawing::ContentAlignment::MiddleRight;
			this->btnGuardarProducto->ImageIndex = 0;
			this->btnGuardarProducto->ImageList = this->imageList1;
			this->btnGuardarProducto->Location = System::Drawing::Point(6, 15);
			this->btnGuardarProducto->Name = L"btnGuardarProducto";
			this->btnGuardarProducto->Size = System::Drawing::Size(119, 44);
			this->btnGuardarProducto->TabIndex = 0;
			this->btnGuardarProducto->Text = L"Guardar";
			this->btnGuardarProducto->UseVisualStyleBackColor = true;
			this->btnGuardarProducto->Click += gcnew System::EventHandler(this, &frmProductos::btnGuardarProducto_Click);
			// 
			// groupBox2
			// 
			this->groupBox2->Controls->Add(this->dgvProductos);
			this->groupBox2->Location = System::Drawing::Point(12, 254);
			this->groupBox2->Name = L"groupBox2";
			this->groupBox2->Size = System::Drawing::Size(560, 188);
			this->groupBox2->TabIndex = 75;
			this->groupBox2->TabStop = false;
			this->groupBox2->Text = L"Listado de productos";
			// 
			// dgvProductos
			// 
			this->dgvProductos->AllowUserToAddRows = false;
			this->dgvProductos->AllowUserToDeleteRows = false;
			this->dgvProductos->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->dgvProductos->Columns->AddRange(gcnew cli::array< System::Windows::Forms::DataGridViewColumn^  >(7) {this->Nro, this->CI, 
				this->Nombre, this->Saldo, this->Precio1, this->Precio2, this->Precio3});
			this->dgvProductos->Location = System::Drawing::Point(6, 19);
			this->dgvProductos->Name = L"dgvProductos";
			this->dgvProductos->Size = System::Drawing::Size(544, 163);
			this->dgvProductos->TabIndex = 0;
			// 
			// Nro
			// 
			this->Nro->HeaderText = L"#";
			this->Nro->Name = L"Nro";
			// 
			// CI
			// 
			this->CI->HeaderText = L"Nro.Prod";
			this->CI->Name = L"CI";
			// 
			// Nombre
			// 
			this->Nombre->HeaderText = L"Descripci�n";
			this->Nombre->Name = L"Nombre";
			// 
			// Saldo
			// 
			this->Saldo->HeaderText = L"Cantidad";
			this->Saldo->Name = L"Saldo";
			// 
			// Precio1
			// 
			this->Precio1->HeaderText = L"Precio 1";
			this->Precio1->Name = L"Precio1";
			// 
			// Precio2
			// 
			this->Precio2->HeaderText = L"Precio 2 ";
			this->Precio2->Name = L"Precio2";
			// 
			// Precio3
			// 
			this->Precio3->HeaderText = L"Precio 3";
			this->Precio3->Name = L"Precio3";
			// 
			// label6
			// 
			this->label6->AutoSize = true;
			this->label6->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 10.2F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->label6->Location = System::Drawing::Point(32, 207);
			this->label6->Margin = System::Windows::Forms::Padding(2, 0, 2, 0);
			this->label6->Name = L"label6";
			this->label6->Size = System::Drawing::Size(158, 17);
			this->label6->TabIndex = 77;
			this->label6->Text = L"Precio 2 ... (Fidalga)";
			// 
			// txtPrecio2
			// 
			this->txtPrecio2->Location = System::Drawing::Point(192, 207);
			this->txtPrecio2->Margin = System::Windows::Forms::Padding(2);
			this->txtPrecio2->Name = L"txtPrecio2";
			this->txtPrecio2->Size = System::Drawing::Size(76, 20);
			this->txtPrecio2->TabIndex = 5;
			// 
			// label7
			// 
			this->label7->AutoSize = true;
			this->label7->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 10.2F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->label7->Location = System::Drawing::Point(34, 231);
			this->label7->Margin = System::Windows::Forms::Padding(2, 0, 2, 0);
			this->label7->Name = L"label7";
			this->label7->Size = System::Drawing::Size(154, 17);
			this->label7->TabIndex = 79;
			this->label7->Text = L"Precio 3  .(IC Norte)";
			// 
			// txtPrecio3
			// 
			this->txtPrecio3->Location = System::Drawing::Point(192, 231);
			this->txtPrecio3->Margin = System::Windows::Forms::Padding(2);
			this->txtPrecio3->Name = L"txtPrecio3";
			this->txtPrecio3->Size = System::Drawing::Size(76, 20);
			this->txtPrecio3->TabIndex = 6;
			// 
			// frmProductos
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->BackColor = System::Drawing::Color::LightSalmon;
			this->ClientSize = System::Drawing::Size(574, 454);
			this->Controls->Add(this->label7);
			this->Controls->Add(this->txtPrecio3);
			this->Controls->Add(this->label6);
			this->Controls->Add(this->txtPrecio2);
			this->Controls->Add(this->groupBox2);
			this->Controls->Add(this->groupBox1);
			this->Controls->Add(this->label3);
			this->Controls->Add(this->label1);
			this->Controls->Add(this->txtPrecio1);
			this->Controls->Add(this->txtDescripcion);
			this->Controls->Add(this->label5);
			this->Controls->Add(this->label4);
			this->Controls->Add(this->txtCantidad);
			this->Controls->Add(this->txtNroProducto);
			this->Controls->Add(this->label2);
			this->MaximizeBox = false;
			this->Name = L"frmProductos";
			this->StartPosition = System::Windows::Forms::FormStartPosition::CenterScreen;
			this->Text = L"PRODUCTOS";
			this->Load += gcnew System::EventHandler(this, &frmProductos::frmProductos_Load);
			this->groupBox1->ResumeLayout(false);
			this->groupBox2->ResumeLayout(false);
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->dgvProductos))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion

	private: System::Void Procesar_Limpiar_Producto()
			 {
	               txtNroProducto->Clear();
				   txtDescripcion->Clear();
				   txtPrecio1->Clear();				   
				   txtPrecio2->Clear();				   
				   txtPrecio3->Clear();				   
				   txtCantidad->Clear();				   
			 }

		private: bool Procesar_Validar_Registro_Producto()
			 {
				 
				   bool respuesta=true;
				   if(txtNroProducto->Text!="")
				   {
					   
					   if(txtDescripcion->Text!="")
					   {
						   if(txtCantidad->Text!="")
						   {
							   if(txtPrecio1->Text!="")
							   {								   
								   if(txtPrecio2->Text!="")
								   {									   
									   if(txtPrecio3->Text!="")
									   {
										   respuesta=true;
									   }
									   else
									   {
										 MessageBox::Show( "El precio 3 no es v�lido" );
										 txtPrecio3->Focus();
										 respuesta=false;
									   }
								   }
								   else
								   {
									 MessageBox::Show( "El precio 2 no es v�lido" );
									 txtPrecio2->Focus();
									 respuesta=false;
								   }
							   }
							   else
							   {
								 MessageBox::Show( "El precio 1 no es v�lido" );
								 txtPrecio1->Focus();
								 respuesta=false;
							   }

						   }
						   else
						   {
							 MessageBox::Show( "La cantidad no es valida" );
							 txtCantidad->Focus();
							 respuesta=false;
						   }
					   }
					   else
					   {
						 MessageBox::Show( "La descripci�n no es v�lida" );
						 txtDescripcion->Focus();
						 respuesta=false;
					   }
				   }
				   else
				   {
                     MessageBox::Show( "El c�digo del producto no es valido" );
					 txtNroProducto->Focus();
				     respuesta=false;
				   }
				   return respuesta;
			 }

	private: System::Void btnCrearArchivo_Click(System::Object^  sender, System::EventArgs^  e) {

				alias=fopen("PRODUCTO.SEC","wb+");			 
				fclose(alias); // Cierra el archivo
                MessageBox::Show( "El archivo fue creado" );

			 }
private: System::Void btnGuardar_Click(System::Object^  sender, System::EventArgs^  e) {

/*
		int no_prod;
		char descrip[30];
	    int cantidad;
		float precio;
		char garantia;
*/
/*
                alias=fopen("PRODUCTO.SEC","ab");			 
				std::string desc;
				desc=marshal_as<std::string>(Convert::ToString(txtDescripcion->Text));
				strcpy(Registro.descrip, desc.c_str());
				
				Registro.no_prod=Convert::ToInt32(txtNroProducto->Text);				
				Registro.cantidad=Convert::ToInt32(txtCantidad->Text);
				Registro.precio=Convert::ToDouble(txtPrecio->Text);
				Registro.garantia='S';

				fwrite(&Registro,sizeof(Registro),1,alias); // Grabar el Registro
				fclose(alias); // Cierra el archivo

				Procesar_Limpiar_Producto();
				 MessageBox::Show( "Registro agregado" );

*/
		 }
private: System::Void btnMostrarTodos_Click(System::Object^  sender, System::EventArgs^  e) {

        /*   
		int no_prod;
		char descrip[30];
	    int cantidad;
		float precio;
		char garantia;
		*/
        /*
 			 std::string desc;
			 std::string gara;
             String^ mensaje="";
			 int contador=0;
			 alias=fopen("PRODUCTO.SEC","rb+");
			 if(alias!=NULL)
			 {
			 
				fread(&Registro,sizeof(Registro),1,alias);
				// Lee el "Registro", de tamano=sizeof(Registro) del archivo "alias"
				while(!feof(alias)) // Ciclo mientras no se encuentre el final del archivo
				
				{
					contador++;
					desc=Registro.descrip;
					gara=Registro.garantia;

					mensaje="Producto nro:" + Convert::ToString(contador) + "\n";
					mensaje+="Codigo:" +Convert::ToString(Registro.no_prod);
					mensaje+="::Nombre:" + gcnew String(desc.c_str());
					mensaje+="::Cantidad:" +Convert::ToString(Registro.cantidad);
					mensaje+="::Precio:" +Convert::ToString(Registro.precio);
					mensaje+="::Garantia:" + gcnew String(gara.c_str());
					MessageBox::Show( mensaje);

					fread(&Registro,sizeof(Registro),1,alias);//lee el siguiente registro o bloque de archivo
				}
			    fclose(alias);
			 }
			 else
			 {
			    MessageBox::Show( "El archivo no existe" );
			 }
         */
		 }
private: System::Void btnGuardarProducto_Click(System::Object^  sender, System::EventArgs^  e) {

/*
		int no_prod;
		char descrip[50];
	    int cantidad;
		float precio1;
		float precio2;
		float precio3;
*/

			 if(Procesar_Validar_Registro_Producto())
			 {
                alias=fopen("SUPERPRODUCTO.SEC","ab");			 
				std::string desc;
				desc=marshal_as<std::string>(Convert::ToString(txtDescripcion->Text));
				strcpy(Registro.descrip, desc.c_str());
				
				Registro.no_prod=Convert::ToInt32(txtNroProducto->Text);				
				Registro.cantidad=Convert::ToInt32(txtCantidad->Text);
				Registro.precio1=Convert::ToDouble(txtPrecio1->Text);
				Registro.precio2=Convert::ToDouble(txtPrecio2->Text);
				Registro.precio3=Convert::ToDouble(txtPrecio3->Text);

				fwrite(&Registro,sizeof(Registro),1,alias); // Grabar el Registro
				fclose(alias); // Cierra el archivo

				Procesar_Limpiar_Producto();
				MessageBox::Show( "Registro agregado" );
			 }
		 }
private: System::Void btnListadoProducto_Click(System::Object^  sender, System::EventArgs^  e) {

        /*   
		int no_prod;
		char descrip[30];
	    int cantidad;
		float precio;
		char garantia;
		*/
 			 std::string desc;
			 std::string gara;
             String^ mensaje="";
			 int contador=0;
			 dgvProductos->Rows->Clear();
			 alias=fopen("SUPERPRODUCTO.SEC","rb+");
			 if(alias!=NULL)
			 {
			 
				fread(&Registro,sizeof(Registro),1,alias);
				// Lee el "Registro", de tamano=sizeof(Registro) del archivo "alias"
				while(!feof(alias)) // Ciclo mientras no se encuentre el final del archivo
				
				{
					contador++;
					desc=Registro.descrip;
					//gara=Registro.garantia;

					mensaje="Producto nro:" + Convert::ToString(contador) + "\n";
					mensaje+="Codigo:" +Convert::ToString(Registro.no_prod);
					mensaje+="::Nombre:" + gcnew String(desc.c_str());
					mensaje+="::Cantidad:" +Convert::ToString(Registro.cantidad);
					//mensaje+="::Precio:" +Convert::ToString(Registro.precio);
					//mensaje+="::Garantia:" + gcnew String(gara.c_str());
					//MessageBox::Show( mensaje);

					dgvProductos->Rows->Add();
					dgvProductos[0,contador-1]->Value=Convert::ToString(contador);
					dgvProductos[1,contador-1]->Value=Convert::ToString(Registro.no_prod);
					dgvProductos[2,contador-1]->Value=gcnew String(desc.c_str());
					dgvProductos[3,contador-1]->Value=Convert::ToString(Registro.cantidad);
					dgvProductos[4,contador-1]->Value=Convert::ToString(Registro.precio1);
					dgvProductos[5,contador-1]->Value=Convert::ToString(Registro.precio2);
					dgvProductos[6,contador-1]->Value=Convert::ToString(Registro.precio3);

					fread(&Registro,sizeof(Registro),1,alias);//lee el siguiente registro o bloque de archivo
				}
			    fclose(alias);
			 }
			 else
			 {
			    MessageBox::Show( "El archivo no existe" );
			 }

		 }
private: System::Void frmProductos_Load(System::Object^  sender, System::EventArgs^  e) {
		 }
};
}
