#include "StdAfx.h"
#include "frmMenuPrincipal.h"

