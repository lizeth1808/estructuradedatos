#pragma once
#include "string"

using namespace std;

class Nodo
{
 private:
    int Codigo;
	string Descripcion;
	float  Precio;
	float  Cantidad;

 public:
	Nodo(void);
	void Agregar(int cod,string des, float pre,float can);
	double Get_Precio();
	string Get_Descripcion();
};

