#include "StdAfx.h"
#include "Persona.h"


Persona::Persona(void)
{Saldo=50;
CI=0;
Nombre=' ';
}

void Persona::Set_Nombre (string nom)
{Nombre=nom;
}

string Persona::Get_Nombre()
{return Nombre;
}

void Persona::Set_Saldo (double sal)
{Saldo=sal;
}

double Persona::Get_Saldo()
{return Saldo;
}

void Persona::Set_CI (int c)
{CI=c;
}

int Persona::Get_CI()
{return CI;
}