#include "StdAfx.h"
#include "Nodo.h"


Nodo::Nodo(void)
{
	Precio=0;
    Descripcion= ' ';
	Precio=0;
	Cantidad=0;
}

void Nodo::Agregar(int cod,string des, float pre,float can)
{
	Codigo=cod;
	Descripcion=des;
    Precio=pre;
	Cantidad=can;
}

double Nodo::Get_Precio()
{return Precio;
}


string Nodo::Get_Descripcion()
{
	return Descripcion;
}