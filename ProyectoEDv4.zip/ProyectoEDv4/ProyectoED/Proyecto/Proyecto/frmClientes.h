#pragma once
#include "Persona.h"

namespace Proyecto {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace std;
	using namespace msclr::interop;
	 
	/// <summary>
	/// Summary for Intr
	/// </summary>

	struct struct_cliente
	{
		int  ci;
		char nombre[50];
		float saldo;
	};



	static struct struct_cliente registro_cliente;
	
	static FILE *archivo_cliente;

	public ref class frmClientes : public System::Windows::Forms::Form
	{

	public:
		frmClientes(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~frmClientes()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Label^  label2;
	private: System::Windows::Forms::Label^  label1;
	private: System::Windows::Forms::Label^  label3;
	public: System::Windows::Forms::TextBox^  txtNombre;
	private: 

	public: System::Windows::Forms::TextBox^  txtSaldo;
	private: 



	public: 

	public: 

	private: System::Windows::Forms::Label^  label4;
	private: System::Windows::Forms::Label^  label5;
	public: System::Windows::Forms::TextBox^  txtCI;
	private: 

	private: System::ComponentModel::IContainer^  components;
	public: 
	private: 


	public: 

	protected: 

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>

	private: System::Windows::Forms::GroupBox^  groupBox1;
	private: System::Windows::Forms::Button^  btnListado;
	private: System::Windows::Forms::Button^  btnGuardar;
	private: System::Windows::Forms::GroupBox^  groupBox2;
	private: System::Windows::Forms::ImageList^  imageList1;
	private: System::Windows::Forms::DataGridView^  dgvClientes;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  Nro;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  CI;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  Nombre;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  Saldo;




			 Persona *A;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->components = (gcnew System::ComponentModel::Container());
			System::ComponentModel::ComponentResourceManager^  resources = (gcnew System::ComponentModel::ComponentResourceManager(frmClientes::typeid));
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->txtNombre = (gcnew System::Windows::Forms::TextBox());
			this->txtSaldo = (gcnew System::Windows::Forms::TextBox());
			this->label4 = (gcnew System::Windows::Forms::Label());
			this->label5 = (gcnew System::Windows::Forms::Label());
			this->txtCI = (gcnew System::Windows::Forms::TextBox());
			this->groupBox1 = (gcnew System::Windows::Forms::GroupBox());
			this->btnListado = (gcnew System::Windows::Forms::Button());
			this->imageList1 = (gcnew System::Windows::Forms::ImageList(this->components));
			this->btnGuardar = (gcnew System::Windows::Forms::Button());
			this->groupBox2 = (gcnew System::Windows::Forms::GroupBox());
			this->dgvClientes = (gcnew System::Windows::Forms::DataGridView());
			this->Nro = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->CI = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->Nombre = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->Saldo = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->groupBox1->SuspendLayout();
			this->groupBox2->SuspendLayout();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->dgvClientes))->BeginInit();
			this->SuspendLayout();
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 10.2F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->label2->Location = System::Drawing::Point(57, 163);
			this->label2->Margin = System::Windows::Forms::Padding(2, 0, 2, 0);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(64, 17);
			this->label2->TabIndex = 2;
			this->label2->Text = L"Nombre";
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->BackColor = System::Drawing::Color::Red;
			this->label1->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 48, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->label1->ForeColor = System::Drawing::Color::LavenderBlush;
			this->label1->Image = (cli::safe_cast<System::Drawing::Image^  >(resources->GetObject(L"label1.Image")));
			this->label1->Location = System::Drawing::Point(28, 15);
			this->label1->Margin = System::Windows::Forms::Padding(2, 0, 2, 0);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(399, 73);
			this->label1->TabIndex = 3;
			this->label1->Text = L"�Bienvenido!";
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->Location = System::Drawing::Point(68, 107);
			this->label3->Margin = System::Windows::Forms::Padding(2, 0, 2, 0);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(269, 13);
			this->label3->TabIndex = 5;
			this->label3->Text = L"Estamos aqui para ayudarte, porfavor ingresa tus datos.";
			// 
			// txtNombre
			// 
			this->txtNombre->CharacterCasing = System::Windows::Forms::CharacterCasing::Upper;
			this->txtNombre->Location = System::Drawing::Point(125, 163);
			this->txtNombre->Margin = System::Windows::Forms::Padding(2);
			this->txtNombre->MaxLength = 50;
			this->txtNombre->Name = L"txtNombre";
			this->txtNombre->Size = System::Drawing::Size(163, 20);
			this->txtNombre->TabIndex = 2;
			// 
			// txtSaldo
			// 
			this->txtSaldo->Location = System::Drawing::Point(125, 187);
			this->txtSaldo->Margin = System::Windows::Forms::Padding(2);
			this->txtSaldo->MaxLength = 4;
			this->txtSaldo->Name = L"txtSaldo";
			this->txtSaldo->Size = System::Drawing::Size(76, 20);
			this->txtSaldo->TabIndex = 3;
			// 
			// label4
			// 
			this->label4->AutoSize = true;
			this->label4->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 10.2F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->label4->Location = System::Drawing::Point(57, 189);
			this->label4->Margin = System::Windows::Forms::Padding(2, 0, 2, 0);
			this->label4->Name = L"label4";
			this->label4->Size = System::Drawing::Size(49, 17);
			this->label4->TabIndex = 10;
			this->label4->Text = L"Saldo";
			// 
			// label5
			// 
			this->label5->AutoSize = true;
			this->label5->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 10.2F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->label5->Location = System::Drawing::Point(57, 141);
			this->label5->Margin = System::Windows::Forms::Padding(2, 0, 2, 0);
			this->label5->Name = L"label5";
			this->label5->Size = System::Drawing::Size(32, 17);
			this->label5->TabIndex = 11;
			this->label5->Text = L"C.I.";
			// 
			// txtCI
			// 
			this->txtCI->Location = System::Drawing::Point(125, 139);
			this->txtCI->Margin = System::Windows::Forms::Padding(2);
			this->txtCI->MaxLength = 8;
			this->txtCI->Name = L"txtCI";
			this->txtCI->Size = System::Drawing::Size(76, 20);
			this->txtCI->TabIndex = 1;
			// 
			// groupBox1
			// 
			this->groupBox1->Controls->Add(this->btnListado);
			this->groupBox1->Controls->Add(this->btnGuardar);
			this->groupBox1->Location = System::Drawing::Point(293, 123);
			this->groupBox1->Name = L"groupBox1";
			this->groupBox1->Size = System::Drawing::Size(134, 114);
			this->groupBox1->TabIndex = 13;
			this->groupBox1->TabStop = false;
			// 
			// btnListado
			// 
			this->btnListado->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->btnListado->ImageAlign = System::Drawing::ContentAlignment::MiddleRight;
			this->btnListado->ImageIndex = 1;
			this->btnListado->ImageList = this->imageList1;
			this->btnListado->Location = System::Drawing::Point(6, 65);
			this->btnListado->Name = L"btnListado";
			this->btnListado->Size = System::Drawing::Size(119, 42);
			this->btnListado->TabIndex = 1;
			this->btnListado->Text = L"Listado";
			this->btnListado->UseVisualStyleBackColor = true;
			this->btnListado->Click += gcnew System::EventHandler(this, &frmClientes::btnListado_Click);
			// 
			// imageList1
			// 
			this->imageList1->ImageStream = (cli::safe_cast<System::Windows::Forms::ImageListStreamer^  >(resources->GetObject(L"imageList1.ImageStream")));
			this->imageList1->TransparentColor = System::Drawing::Color::Transparent;
			this->imageList1->Images->SetKeyName(0, L"Diskette.ico");
			this->imageList1->Images->SetKeyName(1, L"listado1.png");
			// 
			// btnGuardar
			// 
			this->btnGuardar->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->btnGuardar->ImageAlign = System::Drawing::ContentAlignment::MiddleRight;
			this->btnGuardar->ImageIndex = 0;
			this->btnGuardar->ImageList = this->imageList1;
			this->btnGuardar->Location = System::Drawing::Point(6, 15);
			this->btnGuardar->Name = L"btnGuardar";
			this->btnGuardar->Size = System::Drawing::Size(119, 44);
			this->btnGuardar->TabIndex = 0;
			this->btnGuardar->Text = L"Guardar";
			this->btnGuardar->UseVisualStyleBackColor = true;
			this->btnGuardar->Click += gcnew System::EventHandler(this, &frmClientes::btnGuardar_Click);
			// 
			// groupBox2
			// 
			this->groupBox2->Controls->Add(this->dgvClientes);
			this->groupBox2->Location = System::Drawing::Point(12, 243);
			this->groupBox2->Name = L"groupBox2";
			this->groupBox2->Size = System::Drawing::Size(415, 188);
			this->groupBox2->TabIndex = 14;
			this->groupBox2->TabStop = false;
			this->groupBox2->Text = L"Listado de productos";
			// 
			// dgvClientes
			// 
			this->dgvClientes->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->dgvClientes->Columns->AddRange(gcnew cli::array< System::Windows::Forms::DataGridViewColumn^  >(4) {this->Nro, this->CI, 
				this->Nombre, this->Saldo});
			this->dgvClientes->Location = System::Drawing::Point(6, 19);
			this->dgvClientes->Name = L"dgvClientes";
			this->dgvClientes->Size = System::Drawing::Size(400, 163);
			this->dgvClientes->TabIndex = 0;
			// 
			// Nro
			// 
			this->Nro->HeaderText = L"Nro";
			this->Nro->Name = L"Nro";
			// 
			// CI
			// 
			this->CI->HeaderText = L"C.I.";
			this->CI->Name = L"CI";
			// 
			// Nombre
			// 
			this->Nombre->HeaderText = L"Nombre";
			this->Nombre->Name = L"Nombre";
			// 
			// Saldo
			// 
			this->Saldo->HeaderText = L"Saldo";
			this->Saldo->Name = L"Saldo";
			// 
			// frmClientes
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->BackColor = System::Drawing::Color::LightSalmon;
			this->ClientSize = System::Drawing::Size(439, 443);
			this->Controls->Add(this->groupBox2);
			this->Controls->Add(this->groupBox1);
			this->Controls->Add(this->txtCI);
			this->Controls->Add(this->label5);
			this->Controls->Add(this->label4);
			this->Controls->Add(this->txtSaldo);
			this->Controls->Add(this->txtNombre);
			this->Controls->Add(this->label3);
			this->Controls->Add(this->label1);
			this->Controls->Add(this->label2);
			this->Margin = System::Windows::Forms::Padding(2);
			this->MaximizeBox = false;
			this->Name = L"frmClientes";
			this->StartPosition = System::Windows::Forms::FormStartPosition::CenterScreen;
			this->Text = L"CLIENTES";
			this->Load += gcnew System::EventHandler(this, &frmClientes::frmClientes_Load);
			this->groupBox1->ResumeLayout(false);
			this->groupBox2->ResumeLayout(false);
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->dgvClientes))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void Procesar_Limpiar_Cliente()
			 {
	               txtCI->Clear();
				   txtNombre->Clear();
				   txtSaldo->Clear();				   
			 }

	private: bool Procesar_Validar_Registro_Cliente()
			 {
				 
				   bool respuesta=true;
				   if(txtCI->Text!="")
				   {
					   
					   if(txtNombre->Text!="")
					   {
						   if(txtSaldo->Text!="")
						   {
							   respuesta=true;
						   }
						   else
						   {
							 MessageBox::Show( "Saldo no es valido" );
							 txtSaldo->Focus();
							 respuesta=false;
						   }

					   }
					   else
					   {
						 MessageBox::Show( "El Nombre no es valido" );
						 txtNombre->Focus();
						 respuesta=false;
					   }
				   }
				   else
				   {
                     MessageBox::Show( "El CI no es valido" );
					 txtCI->Focus();
				     respuesta=false;
				   }
				   return respuesta;
			 }

	private: System::Void button1_Click(System::Object^  sender, System::EventArgs^  e) {
		string nom;
		nom=marshal_as<string>(Convert::ToString(txtNombre->Text));
		A->Set_Nombre(nom);

			 }
private: System::Void button2_Click(System::Object^  sender, System::EventArgs^  e) {
		 }
private: System::Void btnGuardar_Click(System::Object^  sender, System::EventArgs^  e) 
		 {

/*
	struct struct_cliente
	{
		int  ci;
		char nombre[50];
		float saldo;
	};
*/
			 if(Procesar_Validar_Registro_Cliente())
			 {
                archivo_cliente=fopen("SUPERCLIENTE.SEC","ab");			 
				//std::string nomb;
				string nomb;
				nomb=marshal_as<std::string>(Convert::ToString(txtNombre->Text));
				strcpy(registro_cliente.nombre, nomb.c_str());
				
				registro_cliente.ci=Convert::ToInt32(txtCI->Text);				
				registro_cliente.saldo=Convert::ToDouble(txtSaldo->Text);

				
				fwrite(&registro_cliente,sizeof(registro_cliente),1,archivo_cliente); // Grabar el Registro
				fclose(archivo_cliente); // Cierra el archivo

				Procesar_Limpiar_Cliente();
				MessageBox::Show( "Registro agregado" );
			 }
		 }
private: System::Void btnListado_Click(System::Object^  sender, System::EventArgs^  e) {

 			 string nomb;
			 string gara;
        
			 int contador=0;
			 dgvClientes->Rows->Clear();
			 dgvClientes->RowCount=100;
			 archivo_cliente=fopen("SUPERCLIENTE.SEC","rb");
			 if(archivo_cliente!=NULL)
			 {
			 
				fread(&registro_cliente,sizeof(registro_cliente),1,archivo_cliente);
				// Lee el "Registro", de tamano=sizeof(Registro) del archivo "alias"
				while(!feof(archivo_cliente)) // Ciclo mientras no se encuentre el final del archivo				
				{
					contador++;
					nomb=registro_cliente.nombre;

					//dgvClientes->Rows->Add();
					dgvClientes[0,contador-1]->Value=Convert::ToString(contador);

					dgvClientes[1,contador-1]->Value=Convert::ToString(registro_cliente.ci);
					//dgvClientes->Rows[contador-1]->Cells[1]->Value=System::Convert::ToString(n1);

					//dgvClientes[2,contador-1]->Value=Convert::ToString(nomb);
					dgvClientes[2,contador-1]->Value=gcnew String(nomb.c_str());
					

					dgvClientes[3,contador-1]->Value=Convert::ToString(registro_cliente.saldo);
					//GridProducto->Rows[0]->Cells[1]->Value=System::Convert::ToString(n1);

					fread(&registro_cliente,sizeof(registro_cliente),1,archivo_cliente);//lee el siguiente registro de archivo
				}
			    fclose(archivo_cliente);
			 }
			 else
			 {
			    MessageBox::Show( "El archivo no existe" );
			 }

		 }
private: System::Void frmClientes_Load(System::Object^  sender, System::EventArgs^  e) {
		 }
};
}
