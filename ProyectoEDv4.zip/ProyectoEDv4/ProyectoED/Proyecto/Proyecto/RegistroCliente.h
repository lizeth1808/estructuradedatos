	struct struct_cliente
	{
		int  ci;
		char nombre[50];
		float saldo;
	};