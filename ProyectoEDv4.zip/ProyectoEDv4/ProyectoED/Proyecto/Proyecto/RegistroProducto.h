	struct struct_producto
	{
		int no_prod;
		char descrip[50];
	    int cantidad;
		float precio1;
		float precio2;
		float precio3;		
	};