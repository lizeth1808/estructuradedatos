#pragma once
#include "frmCompras.h"
#include "frmClientes.h"
namespace Proyecto {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// Summary for frmMenuPrincipal
	/// </summary>
	public ref class frmMenuPrincipal : public System::Windows::Forms::Form
	{
	public:
		frmMenuPrincipal(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~frmMenuPrincipal()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Button^  btnClientes;
	protected: 

	private: System::Windows::Forms::Button^  btnComprar;
	private: System::Windows::Forms::Label^  label1;
	private: System::Windows::Forms::ImageList^  imageList1;
	private: System::ComponentModel::IContainer^  components;

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>


#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->components = (gcnew System::ComponentModel::Container());
			System::ComponentModel::ComponentResourceManager^  resources = (gcnew System::ComponentModel::ComponentResourceManager(frmMenuPrincipal::typeid));
			this->btnClientes = (gcnew System::Windows::Forms::Button());
			this->imageList1 = (gcnew System::Windows::Forms::ImageList(this->components));
			this->btnComprar = (gcnew System::Windows::Forms::Button());
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->SuspendLayout();
			// 
			// btnClientes
			// 
			this->btnClientes->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->btnClientes->ImageAlign = System::Drawing::ContentAlignment::MiddleRight;
			this->btnClientes->ImageIndex = 0;
			this->btnClientes->ImageList = this->imageList1;
			this->btnClientes->Location = System::Drawing::Point(151, 128);
			this->btnClientes->Name = L"btnClientes";
			this->btnClientes->Size = System::Drawing::Size(136, 36);
			this->btnClientes->TabIndex = 0;
			this->btnClientes->Text = L"CLIENTES";
			this->btnClientes->UseVisualStyleBackColor = true;
			this->btnClientes->Click += gcnew System::EventHandler(this, &frmMenuPrincipal::btnClientes_Click);
			// 
			// imageList1
			// 
			this->imageList1->ImageStream = (cli::safe_cast<System::Windows::Forms::ImageListStreamer^  >(resources->GetObject(L"imageList1.ImageStream")));
			this->imageList1->TransparentColor = System::Drawing::Color::Transparent;
			this->imageList1->Images->SetKeyName(0, L"customer1.png");
			this->imageList1->Images->SetKeyName(1, L"productos1.png");
			this->imageList1->Images->SetKeyName(2, L"venta1.png");
			// 
			// btnComprar
			// 
			this->btnComprar->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->btnComprar->ImageAlign = System::Drawing::ContentAlignment::MiddleRight;
			this->btnComprar->ImageIndex = 2;
			this->btnComprar->ImageList = this->imageList1;
			this->btnComprar->Location = System::Drawing::Point(151, 170);
			this->btnComprar->Name = L"btnComprar";
			this->btnComprar->Size = System::Drawing::Size(136, 38);
			this->btnComprar->TabIndex = 2;
			this->btnComprar->Text = L"COMPRAR";
			this->btnComprar->UseVisualStyleBackColor = true;
			this->btnComprar->Click += gcnew System::EventHandler(this, &frmMenuPrincipal::btnComprar_Click);
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->BackColor = System::Drawing::Color::Red;
			this->label1->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 48, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->label1->ForeColor = System::Drawing::Color::LavenderBlush;
			this->label1->Image = (cli::safe_cast<System::Drawing::Image^  >(resources->GetObject(L"label1.Image")));
			this->label1->Location = System::Drawing::Point(28, 9);
			this->label1->Margin = System::Windows::Forms::Padding(2, 0, 2, 0);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(399, 73);
			this->label1->TabIndex = 4;
			this->label1->Text = L"�Bienvenido!";
			// 
			// frmMenuPrincipal
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->BackColor = System::Drawing::Color::LightSalmon;
			this->ClientSize = System::Drawing::Size(449, 301);
			this->Controls->Add(this->label1);
			this->Controls->Add(this->btnComprar);
			this->Controls->Add(this->btnClientes);
			this->MaximizeBox = false;
			this->Name = L"frmMenuPrincipal";
			this->StartPosition = System::Windows::Forms::FormStartPosition::CenterScreen;
			this->Text = L"MENU PRINCIPAL";
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void btnClientes_Click(System::Object^  sender, System::EventArgs^  e) {
			 frmClientes^ fc=gcnew frmClientes();
			 fc->ShowDialog();
			 }
	private: System::Void btnProductos_Click(System::Object^  sender, System::EventArgs^  e) {


			 }
	private: System::Void btnComprar_Click(System::Object^  sender, System::EventArgs^  e) {

			 frmCompras^ fc=gcnew frmCompras();
			 fc->ShowDialog();

			 }
	};
}
